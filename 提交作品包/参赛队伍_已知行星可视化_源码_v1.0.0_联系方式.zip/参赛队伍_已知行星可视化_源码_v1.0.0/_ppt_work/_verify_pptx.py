"""
_verify_pptx.py —— 验证生成的 pptx 结构完整性

检查：
1. ZIP 包完整性
2. 必需的 OOXML 部件存在
3. [Content_Types].xml 覆盖所有 slide
4. presentation.xml 幻灯片引用与实际文件一致
5. 关系链完整（root → presentation → slides → layout → master → theme）
6. 每个 XML 均可解析
7. 文本内容抽查（标题/要点存在）
"""
import os
import sys
import zipfile
import xml.dom.minidom as minidom
import re

ROOT = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(ROOT)          # 项目根目录 D:\Astrarium
PPTX = os.path.join(PROJECT, "作品说明文档", "已知行星可视化_答辩PPT.pptx")

errors = []
passed = 0
total = 0


def check(name, cond, detail=""):
    global passed, total
    total += 1
    if cond:
        passed += 1
        print(f"  [OK] {name}")
    else:
        errors.append(f"{name}: {detail}")
        print(f"  [FAIL] {name}: {detail}")


print("=== 1. ZIP 完整性 ===")
z = zipfile.ZipFile(PPTX)
bad = z.testzip()
check("ZIP 无损坏", bad is None, f"坏文件: {bad}")
names = z.namelist()
print(f"  共 {len(names)} 个部件")

print("\n=== 2. 必需部件 ===")
required = [
    "[Content_Types].xml", "_rels/.rels",
    "docProps/core.xml", "docProps/app.xml",
    "ppt/presentation.xml", "ppt/_rels/presentation.xml.rels",
    "ppt/theme/theme1.xml",
    "ppt/slideMasters/slideMaster1.xml", "ppt/slideMasters/_rels/slideMaster1.xml.rels",
    "ppt/slideLayouts/slideLayout1.xml", "ppt/slideLayouts/_rels/slideLayout1.xml.rels",
]
for req in required:
    check(f"部件 {req}", req in names)

print("\n=== 3. 幻灯片部件 ===")
slide_parts = sorted([n for n in names if re.match(r"ppt/slides/slide\d+\.xml$", n)])
slide_rels = sorted([n for n in names if re.match(r"ppt/slides/_rels/slide\d+\.xml\.rels$", n)])
check("19 页幻灯片 XML", len(slide_parts) == 19, f"实际 {len(slide_parts)}")
check("19 个幻灯片关系文件", len(slide_rels) == 19, f"实际 {len(slide_rels)}")

print("\n=== 4. XML 可解析性 ===")
parse_fail = []
for name in names:
    if name.endswith(".xml") or name.endswith(".rels"):
        try:
            minidom.parseString(z.read(name))
        except Exception as e:
            parse_fail.append(f"{name}: {e}")
check("全部 XML 可解析", len(parse_fail) == 0, "; ".join(parse_fail[:3]))

print("\n=== 5. Content_Types 覆盖 ===")
ct = z.read("[Content_Types].xml").decode("utf-8")
missing_ct = [f"slide{i}" for i in range(1, 20) if f"/ppt/slides/slide{i}.xml" not in ct]
check("Content_Types 覆盖全部19页", len(missing_ct) == 0, f"缺失: {missing_ct[:3]}")

print("\n=== 6. 关系链 ===")
pres = z.read("ppt/presentation.xml").decode("utf-8")
pres_rels = z.read("ppt/_rels/presentation.xml.rels").decode("utf-8")
# presentation 引用的 slide
ref_ids = re.findall(r'<p:sldId id="\d+" r:id="(rId\d+)"/>', pres)
check("presentation 引用19个slide", len(ref_ids) == 19, f"实际 {len(ref_ids)}")
# 每个引用在 rels 中有对应 target
rel_map = dict(re.findall(r'<Relationship Id="(rId\d+)"[^>]*Target="([^"]+)"', pres_rels))
missing_target = [rid for rid in ref_ids if rid not in rel_map]
check("全部引用有 Target", len(missing_target) == 0, f"缺失: {missing_target[:3]}")
# target 文件存在
missing_file = [rel_map[rid] for rid in ref_ids
                if rid in rel_map and f"ppt/{rel_map[rid]}" not in names]
check("全部 Target 文件存在", len(missing_file) == 0, f"缺失: {missing_file[:3]}")
# master/layout/theme 链
sm_rels = z.read("ppt/slideMasters/_rels/slideMaster1.xml.rels").decode("utf-8")
check("master → layout 关系", "slideLayouts/slideLayout1.xml" in sm_rels)
check("master → theme 关系", "theme/theme1.xml" in sm_rels)
sl_rels = z.read("ppt/slideLayouts/_rels/slideLayout1.xml.rels").decode("utf-8")
check("layout → master 关系", "slideMasters/slideMaster1.xml" in sl_rels)
s1_rels = z.read("ppt/slides/_rels/slide1.xml.rels").decode("utf-8")
check("slide → layout 关系", "slideLayouts/slideLayout1.xml" in s1_rels)

print("\n=== 7. 内容抽查 ===")
import html

def slide_text(name):
    xml_str = z.read(name).decode("utf-8")
    return html.unescape("".join(re.findall(r"<a:t>([^<]*)</a:t>", xml_str)))

expected_contents = {
    1: ["已知行星可视化", "真实天文数据"],
    2: ["为什么做", "Celestia", "NASA Eyes"],
    6: ["Blender", "视角"],
    8: ["天文爱好者", "师生", "科普场馆", "科幻"],
    9: ["码道", "CodeArts", "评分"],
    14: ["Celestia", "Stellarium", "本软件"],
    17: ["局限", "诚实"],
    19: ["Q & A"],
}
content_fail = []
for pageno, keys in expected_contents.items():
    texts = slide_text(f"ppt/slides/slide{pageno}.xml")
    for k in keys:
        if k not in texts:
            content_fail.append(f"P{pageno} 缺 '{k}'")
check("关键内容抽查", len(content_fail) == 0, "; ".join(content_fail[:5]))

# 占位符检查（正常，需用户替换）
texts_all = ""
for name in slide_parts:
    texts_all += slide_text(name)
placeholders = re.findall(r"\{[^}]+\}", texts_all)
if placeholders:
    print(f"  [提示] 存在待替换占位符: {sorted(set(placeholders))}")

print("\n" + "=" * 60)
print(f"PPTX 验证: {passed}/{total} 通过")
if errors:
    for e in errors:
        print(f"  - {e}")
    sys.exit(1)
print("全部通过 ✓")
sys.exit(0)