"""
_build_pptx.py —— 纯标准库生成答辩PPT（创新方案）

不依赖 python-pptx / pptxgenjs（沙箱 pip/npm 网络受限），
用 Python 标准库 zipfile + 手写 OOXML（Office Open XML）构造真正的 .pptx 文件：

    pptx = ZIP 包
    ├── [Content_Types].xml          内容类型
    ├── _rels/.rels                  根关系
    ├── docProps/{core,app}.xml      文档属性
    └── ppt/
        ├── presentation.xml         演示文稿
        ├── theme/theme1.xml         深色主题（Blender配色）
        ├── slideMasters/slideMaster1.xml
        ├── slideLayouts/slideLayout1.xml
        └── slides/slide1..19.xml    19页幻灯片

主题：Blender 深色风格（#1d1d1d 背景 / #e87d0d 橙色强调 / #e5e5e5 文字）
"""
import os
import zipfile
import xml.dom.minidom as minidom

ROOT = os.path.dirname(os.path.abspath(__file__))
PROJECT = os.path.dirname(ROOT)          # 项目根目录 D:\Astrarium
OUT = os.path.join(PROJECT, "作品说明文档", "已知行星可视化_答辩PPT.pptx")

# ---------- 配色（与软件 UI 一致） ----------
BG = "1D1D1D"        # 主背景
PANEL = "333333"     # 卡片/面板
PANEL_L = "3D3D3D"   # 浅面板
ACCENT = "E87D0D"    # Blender 橙
BLUE = "4772B3"      # 科技蓝
TEXT = "E5E5E5"      # 主文字
DIM = "A0A0A0"       # 次要文字
LINE = "252525"      # 细线

# 幻灯片尺寸 16:9（EMU）
SW, SH = 12192000, 6858000


def esc(s: str) -> str:
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


# ---------- 文本元素 ----------
def run(text, sz=1600, color=TEXT, bold=False, italic=False, spacing=None):
    b = ' b="1"' if bold else ""
    i = ' i="1"' if italic else ""
    spc = f' spc="{spacing}"' if spacing else ""
    return (f'<a:r><a:rPr lang="zh-CN" altLang="en-US" sz="{sz}"{b}{i}{spc} dirty="0">'
            f'<a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
            f'<a:latin typeface="Microsoft YaHei UI"/><a:ea typeface="Microsoft YaHei UI"/>'
            f'</a:rPr><a:t>{esc(text)}</a:t></a:r>')


def para(runs_xml, align="l", line=130, before=0, after=0, bullet=None, bullet_color=None):
    pPr = f'<a:pPr algn="{align}">'
    if line:
        pPr += f'<a:lnSpc><a:spcPct val="{line * 1000}"/></a:lnSpc>'
    if before:
        pPr += f'<a:spcBef><a:spcPts val="{before * 100}"/></a:spcBef>'
    if after:
        pPr += f'<a:spcAft><a:spcPts val="{after * 100}"/></a:spcAft>'
    if bullet:
        bc = bullet_color or ACCENT
        pPr += (f'<a:buClr><a:srgbClr val="{bc}"/></a:buClr>'
                f'<a:buFont typeface="Arial"/><a:buChar char="{bullet}"/>')
    else:
        pPr += '<a:buNone/>'
    pPr += '</a:pPr>'
    return f'<a:p>{pPr}{runs_xml}</a:p>'


def textbox(sid, name, x, y, cx, cy, paras, anchor="t", wrap="square"):
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="{esc(name)}"/>'
            f'<p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
            f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
            f'<p:txBody><a:bodyPr wrap="{wrap}" anchor="{anchor}" '
            f'lIns="0" tIns="0" rIns="0" bIns="0"/><a:lstStyle/>{paras}</p:txBody></p:sp>')


def shape(sid, name, x, y, cx, cy, color, prst="rect", adj=None, alpha=None):
    geom = (f'<a:prstGeom prst="{prst}">'
            + (f'<a:avLst><a:gd name="adj" fmla="val {adj}"/></a:avLst>' if adj else '<a:avLst/>')
            + '</a:prstGeom>')
    fill = f'<a:solidFill><a:srgbClr val="{color}"/>'
    if alpha:
        fill += f'<a:alpha val="{alpha}"/>'
    fill += '</a:solidFill>'
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="{esc(name)}"/>'
            f'<p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
            f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
            f'{geom}{fill}<a:ln><a:noFill/></a:ln></p:spPr>'
            f'<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang="zh-CN"/></a:p></p:txBody></p:sp>')


# ---------- 页面骨架 ----------
_page_id = [100]


def _nid():
    _page_id[0] += 1
    return _page_id[0]


def page_base(slide_no, total=19):
    """每页公共元素：底部装饰线 + 页码"""
    els = []
    els.append(shape(_nid(), "bottomline", 0, SH - 40000, SW, 40000, LINE))
    if slide_no > 0:
        els.append(textbox(_nid(), "pagenum", SW - 1000000, SH - 560000, 700000, 300000,
                           para(run(f"{slide_no:02d} / {total}", 1000, DIM), align="r")))
    return els


def header(tag, title, title_color=TEXT):
    """页头：小标签 + 橙色竖条 + 大标题"""
    els = []
    els.append(textbox(_nid(), "tag", 700000, 380000, 8000000, 280000,
                       para(run(tag, 1100, DIM, bold=True, spacing=300))))
    els.append(shape(_nid(), "titlebar", 700000, 820000, 80000, 640000, ACCENT))
    els.append(textbox(_nid(), "title", 900000, 760000, 10500000, 720000,
                       para(run(title, 3200, title_color, bold=True)), anchor="ctr"))
    return els


def content_page(slide_no, tag, title, body_els):
    els = page_base(slide_no)
    els += header(tag, title)
    for e in body_els:
        if isinstance(e, list):
            els.extend(e)
        else:
            els.append(e)
    return els


# ---------- 布局组件 ----------
def bullet_list(x, y, w, items, sz=1600, line=150, gap=6):
    """要点列表：橙色 ▪ 项目符 + 文本"""
    paras = ""
    for i, it in enumerate(items):
        if isinstance(it, tuple):
            head, desc = it
            rs = (run("▪ ", sz, ACCENT, bold=True) + run(head, sz, TEXT, bold=True)
                  + run("  " + desc, sz - 200, DIM))
        else:
            rs = run("▪ ", sz, ACCENT, bold=True) + run(it, sz, TEXT)
        paras += para(rs, line=line, before=(gap if i else 0))
    return textbox(_nid(), "bullets", x, y, w, SH - y - 900000, paras)


def card_grid(x, y, w, h, cards, cols=2, gap=200000):
    """卡片网格：圆角矩形 + 卡片标题 + 描述"""
    rows = (len(cards) + cols - 1) // cols
    cw = (w - (cols - 1) * gap) // cols
    ch = (h - (rows - 1) * gap) // rows
    els = []
    for i, (title, desc) in enumerate(cards):
        r, c = divmod(i, cols)
        cx = x + c * (cw + gap)
        cy = y + r * (ch + gap)
        els.append(shape(_nid(), f"card{i}", cx, cy, cw, ch, PANEL, prst="roundRect", adj=6000))
        els.append(shape(_nid(), f"cardbar{i}", cx, cy + 260000, 90000, 260000, ACCENT))
        els.append(textbox(_nid(), f"cardt{i}", cx + 220000, cy + 240000, cw - 420000, 340000,
                           para(run(title, 1400, TEXT, bold=True))))
        els.append(textbox(_nid(), f"cardd{i}", cx + 220000, cy + 660000, cw - 420000, ch - 800000,
                           para(run(desc, 1100, DIM), line=140)))
    return els


def kpi_row(x, y, w, items):
    """KPI 数字行：大数字 + 小标签"""
    gap = 250000
    cw = (w - (len(items) - 1) * gap) // len(items)
    els = []
    for i, (num, label) in enumerate(items):
        cx = x + i * (cw + gap)
        els.append(shape(_nid(), f"kpi{i}", cx, y, cw, 1500000, PANEL, prst="roundRect", adj=8000))
        els.append(textbox(_nid(), f"kpibar{i}", cx + cw // 2 - 300000, y + 240000, 600000, 10000,
                           para(run("", 800, ACCENT), align="ctr")))
        els.append(textbox(_nid(), f"kpin{i}", cx, y + 320000, cw, 560000,
                           para(run(num, 2800, ACCENT, bold=True), align="ctr")))
        els.append(textbox(_nid(), f"kpil{i}", cx, y + 940000, cw, 400000,
                           para(run(label, 1100, DIM), align="ctr")))
    return els


def table(sid_start, x, y, w, headers, rows, col_ratio=None, row_h=430000, header_h=430000):
    """graphicFrame 表格（深色风格）"""
    ncols = len(headers)
    if col_ratio is None:
        col_ratio = [1.0] * ncols
    total = sum(col_ratio)
    col_w = [int(w * r / total) for r in col_ratio]

    tbl_grid = "".join(f'<a:gridCol w="{cw}"/>' for cw in col_w)

    def cell(text, sz, color, fill, bold=False, align="l"):
        tcPr = (f'<a:tcPr marL="80000" marR="80000" marT="30000" marB="30000" anchor="ctr">'
                f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>'
                f'<a:lnL w="6350"><a:solidFill><a:srgbClr val="{LINE}"/></a:solidFill></a:lnL>'
                f'<a:lnR w="6350"><a:solidFill><a:srgbClr val="{LINE}"/></a:solidFill></a:lnR>'
                f'<a:lnT w="6350"><a:solidFill><a:srgbClr val="{LINE}"/></a:solidFill></a:lnT>'
                f'<a:lnB w="6350"><a:solidFill><a:srgbClr val="{LINE}"/></a:solidFill></a:lnB>'
                f'</a:tcPr>')
        return (f'<a:tc><a:txBody><a:bodyPr/><a:lstStyle/>'
                f'<a:p><a:pPr algn="{align}"/>{run(text, sz, color, bold=bold)}</a:p></a:txBody>{tcPr}</a:tc>')

    xml_rows = ""
    hrow = "".join(cell(h, 1200, "FFFFFF", ACCENT, bold=True,
                        align="l" if i == 0 else "ctr") for i, h in enumerate(headers))
    xml_rows += f'<a:tr h="{header_h}">{hrow}</a:tr>'
    for r in rows:
        crow = ""
        for i, v in enumerate(r):
            fill = PANEL if r[0] == "本软件" else PANEL_L if rows.index(r) % 2 else PANEL
            color = ACCENT if (r[0] == "本软件" or (i > 0 and v == "✓")) else (TEXT if i == 0 else DIM)
            crow += cell(v, 1100, color, fill, bold=(i == 0),
                         align="l" if i == 0 else "ctr")
        xml_rows += f'<a:tr h="{row_h}">{crow}</a:tr>'

    row_h_total = header_h + row_h * len(rows)
    return (f'<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="{sid_start}" name="Table"/>'
            f'<p:cNvGraphicFramePr><a:graphicFrameLocks noGrp="1"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>'
            f'<p:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{row_h_total}"/></p:xfrm>'
            f'<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/table">'
            f'<a:tbl><a:tblPr firstRow="1" bandRow="1"/>{tbl_grid}{xml_rows}</a:tbl>'
            f'</a:graphicData></a:graphic></p:graphicFrame>')


# ---------- 19 页内容 ----------
def build_slides():
    slides = []

    # P1 封面
    els = page_base(0)
    els.append(shape(_nid(), "accentline", 5400000, 2350000, 1400000, 50000, ACCENT))
    els.append(textbox(_nid(), "maintitle", 800000, 2600000, 10592000, 1100000,
                       para(run("已知行星可视化", 5400, TEXT, bold=True, spacing=200), align="ctr")))
    els.append(textbox(_nid(), "subtitle", 800000, 3900000, 10592000, 600000,
                       para(run("基于真实天文数据的三维 / 二维行星可视化桌面软件", 2200, ACCENT), align="ctr")))
    els.append(textbox(_nid(), "meta", 800000, 5100000, 10592000, 1000000,
                       para(run("2026 华为开发者大赛 · 上海理工大学站", 1500, DIM), align="ctr", after=6)
                       + para(run("队伍：{队伍名称}   |   成员：{成员名单}   |   2026年10月", 1200, DIM), align="ctr")))
    slides.append(els)

    # P2 场景背景
    els = content_page(2, "01  SCENE BACKGROUND", "为什么做这个？", [
        textbox(_nid(), "left", 700000, 1900000, 5400000, 4400000,
                para(run("现有工具的不足", 1700, ACCENT, bold=True), after=8)
                + para(run("▪ ", 1500, ACCENT, bold=True) + run("Celestia", 1500, TEXT, bold=True)
                       + run("  操作复杂，非专业用户难以上手", 1300, DIM), line=140, before=4)
                + para(run("▪ ", 1500, ACCENT, bold=True) + run("NASA Eyes", 1500, TEXT, bold=True)
                       + run("  仅网页版，无法离线使用", 1300, DIM), line=140, before=4)
                + para(run("▪ ", 1500, ACCENT, bold=True) + run("Stellarium", 1500, TEXT, bold=True)
                       + run("  侧重地面观星，非宇宙空间视角", 1300, DIM), line=140, before=4)),
        shape(_nid(), "divider", 6350000, 2000000, 25000, 3900000, LINE),
        textbox(_nid(), "right", 6700000, 1900000, 4800000, 4400000,
                para(run("用户痛点", 1700, ACCENT, bold=True), after=8)
                + para(run("▪ ", 1500, ACCENT, bold=True) + run("想看行星有多大", 1400, TEXT)
                       + run(" → 缺乏尺寸对比", 1300, DIM), line=140, before=4)
                + para(run("▪ ", 1500, ACCENT, bold=True) + run("想看相对运动", 1400, TEXT)
                       + run(" → 无工具提供此分析", 1300, DIM), line=140, before=4)
                + para(run("▪ ", 1500, ACCENT, bold=True) + run("想浏览系外行星", 1400, TEXT)
                       + run(" → 数据分散无统一视图", 1300, DIM), line=140, before=4)
                + para(run("▪ ", 1500, ACCENT, bold=True) + run("想用于教学", 1400, TEXT)
                       + run(" → 缺乏预设教学场景", 1300, DIM), line=140, before=4)),
    ])
    slides.append(els)

    # P3 产品定位
    els = content_page(3, "02  POSITIONING", "本软件是什么？", [
        card_grid(700000, 1950000, 10790000, 2600000, [
            ("是什么", "桌面端三维宇宙行星可视化软件，将太阳系与系外行星按真实数据统一呈现"),
            ("解决什么", "行星尺寸对比、双行星相对运动分析、系外行星统一可视化三大痛点"),
            ("面向谁", "天文爱好者、师生、科普场馆、科普创作者、科研人员、科幻创作者"),
        ], cols=3),
        textbox(_nid(), "diff", 700000, 4900000, 10790000, 900000,
                para(run("核心差异  ", 1500, ACCENT, bold=True)
                     + run("Blender 式视角操作（业内少有）  +  双行星相对运动分析（现有工具空白）",
                           1500, TEXT), line=140)),
    ])
    slides.append(els)

    # P4 功能框架一
    els = content_page(4, "03  ARCHITECTURE 1/2", "功能框架：核心可视化", [
        kpi_row(700000, 1950000, 10790000, [
            ("23", "太阳系天体（含 13 颗卫星）"),
            ("6375+", "系外行星（NASA 完整目录）"),
            ("62", "真实亮星（Hipparcos）"),
            ("4781", "恒星系（系群）"),
        ]),
        bullet_list(700000, 3900000, 10790000, [
            ("三维 / 二维双视口", "OpenGL 3.3 三维主视口 + QPainter 二维俯视图，启动器一键切换（快捷键 3 / 2）"),
            ("Blender 式视角", "轨道模式 + 飞行模式，对数缩放跨 18 个数量级"),
            ("真实背景", "程序化体积星云 + 真实亮星背景 + 动态黄道网格 + 主带小行星带点云"),
            ("天体数据", "JPL 轨道根数 + NASA 系外行星 6375+ + Hipparcos 亮星，缺失标“未知”"),
        ], sz=1450),
    ])
    slides.append(els)

    # P5 功能框架二
    els = content_page(5, "04  ARCHITECTURE 2/2", "功能框架：分析与教学", [
        card_grid(700000, 1950000, 10790000, 4100000, [
            ("双行星对比分析", "4 种参考系切换，3D 轨迹 + 距离/速度曲线，会合周期计算，CSV/PNG 导出"),
            ("天象推演", "冲日/合日/大距/方照/行星合相/凌日六类事件，扫描求根，点击跳转时间轴"),
            ("观测特征", "凌星光变曲线 + 视向速度曲线 + 宜居带（Kopparapu 2013），三联图导出"),
            ("地面 / 地表视角", "20 观测点地平天球 + 任意天体表面第一人称全景，含日出日落与晨昏"),
            ("时间控制", "9 档倍速（实时×1 ~ 100年/秒）、倒放、日期跳转，全面板时间同步"),
            ("教学与工具", "6 个预设场景一键播放；7 步新手引导；测距；尺寸对比（真实直径比例）"),
        ], cols=3),
    ])
    slides.append(els)

    # P6 核心亮点一
    els = content_page(6, "05  HIGHLIGHTS 1/2", "核心亮点：专业交互", [
        card_grid(700000, 1950000, 10790000, 4100000, [
            ("Blender 式视角操作", "中键旋转 / Shift+中键平移 / 滚轮对数缩放；Numpad 1/3/7 正交视图与 Blender 完全一致；飞行模式 WASD+QE 自由漫游"),
            ("双行星相对运动分析", "4 种参考系（行星A / 行星B / 质心 / 宿主恒星）；3D 真实轨迹与 2D 俯视切换；距离 / 速度曲线随时间同步游标；会合周期自动计算"),
            ("天象推演 + 观测特征", "冲日/合日/大距/方照/合相/凌日六类事件解析求根；凌星光变 / 视向速度 / 宜居带三联图，数值对照真实天文年历"),
            ("地面 / 地表视角", "观测点地平天球（日出日落与三档暮光）+ 任意天体表面第一人称全景（昼夜天光渐变、真实视星等亮度）"),
        ], cols=2),
    ])
    slides.append(els)

    # P7 核心亮点二
    els = content_page(7, "06  HIGHLIGHTS 2/2", "核心亮点：科学诚实", [
        card_grid(700000, 1950000, 10790000, 4100000, [
            ("科学诚实性", "精度分级 A/B/C 标注每个天体；缺失数据如实显示“未知”，禁止伪造；系外行星相位假设值（M(J2000)=0）明确标注，可复现"),
            ("真实天文数据", "JPL 近似轨道根数（含世纪变率）；NASA Exoplanet Archive 6375+ 颗完整目录；Hipparcos 62 颗亮星；主带小行星带按柯克伍德空隙生成"),
        ], cols=1),
    ])
    slides.append(els)

    # P8 赛道应用
    els = content_page(8, "07  APPLICATION", "适用场景：6 类目标用户", [
        card_grid(700000, 1900000, 10790000, 4300000, [
            ("天文爱好者", "搜索 + 聚焦 + 对比，探索行星运动规律"),
            ("师生教学", "教学场景一键播放，开普勒定律直观演示"),
            ("科普场馆", "真实比例 + 飞行模式，大屏互动展示"),
            ("科普创作者", "导出 PNG / CSV，图表直接用于文章视频"),
            ("科研辅助", "精度分级判断可靠性，CSV 数据导出分析"),
            ("科幻创作", "系外行星尺度巡览，多恒星系统布局参考"),
        ], cols=3),
    ])
    slides.append(els)

    # P9 码道使用深度（核心评分点）
    els = content_page(9, "08  CODEARTS ★ 核心评分点", "华为云码道 CodeArts 使用深度", [
        kpi_row(700000, 1900000, 10790000, [
            ("15+", "码道生成/补全模块"),
            ("5", "关键 bug 码道定位修复"),
            ("78", "项验收自测全部通过"),
            ("4-6×", "开发效率提升"),
        ]),
        bullet_list(700000, 3900000, 10790000, [
            ("项目搭建", "从需求文档到代码结构，全程码道辅助生成"),
            ("代码生成", "数据层 / 渲染层 / UI 层 / 天体力学与天象推演 / 教学场景核心代码均由码道完成"),
            ("调试排错", "PyQt5 API 差异、质心参考系回退、中文字体等 bug 定位修复"),
            ("人机分工", "人决策选型与标准，码道执行编码、自测、文档"),
        ], sz=1400, line=140, gap=4),
    ])
    slides.append(els)

    # P10 技术架构
    els = content_page(10, "09  TECH STACK", "技术架构", [
        card_grid(700000, 1950000, 5300000, 4100000, [
            ("core 计算层", "开普勒方程牛顿迭代 / 4 参考系相对运动 / 天象推演求根 / 观测者与地表视角 / 系外行星观测特征 / 儒略日时间系统"),
            ("data 数据层", "Body 统一模型 / 恒星系（系群）分组 / 赤道→黄道转换 / 主带小行星带生成 / CSV 完整目录加载"),
        ], cols=1),
        card_grid(6200000, 1950000, 5290000, 4100000, [
            ("scene 渲染层", "OpenGL 3.3 Core 管线 / 点精灵+线着色器 / 浮点原点偏移 / 程序化表面贴图 / 体积星云 / 二维视口"),
            ("ui 界面层", "PyQt5 深色主题 / 启动器双模式 / 7 标签页面板 / matplotlib 嵌入图表 / 时间轴 / 天体树"),
        ], cols=1),
    ])
    slides.append(els)

    # P11 工程质量
    els = content_page(11, "10  QUALITY", "工程质量", [
        bullet_list(700000, 1950000, 10790000, [
            ("性能优化", "浮点原点偏移（double→float32，跨 18 数量级）；动态 near/far；视锥剔除；小行星带 5 万点 GPU 求解；轨道单次 draw call"),
            ("代码质量", "8 个阶段自测脚本全部通过，78 项验收自测全通过；数据校验 NaN/负数→None；科学诚实性原则贯穿"),
            ("可扩展性", "core/data/scene/ui 四层解耦；CSV 支持完整目录扩展；教学场景与分析面板可持续增加"),
        ], sz=1500),
    ])
    slides.append(els)

    # P12 创新点
    els = content_page(12, "11  INNOVATION", "创新点", [
        card_grid(700000, 1950000, 10790000, 4100000, [
            ("功能创新", "双行星相对运动分析（4 参考系 + 会合周期）+ 天象推演（六类事件求根）—— 现有工具均无"),
            ("技术创新", "浮点原点偏移渲染，跨 18 个数量级无精度爆炸 + 对数缩放"),
            ("体验创新", "Blender 式视角 + 3D/2D 双视口 + 地表第一人称全景 + 6 个教学场景"),
            ("数据创新", "精度分级 A/B/C 标注 + 科学诚实性原则（缺失不伪造、假设可复现）"),
        ], cols=2),
    ])
    slides.append(els)

    # P13 专业贴合度
    els = content_page(13, "12  PROFESSIONAL", "专业贴合度", [
        bullet_list(700000, 1950000, 10790000, [
            ("数据来源", "JPL Horizons / NASA Exoplanet Archive / Hipparcos 三大权威数据源"),
            ("轨道计算", "JPL 近似根数 + 世纪变率修正，开普勒方程牛顿迭代求解"),
            ("坐标系统", "J2000 黄道坐标系统一，赤道坐标经黄赤交角旋转转入"),
            ("精度分级", "A（JPL 权威）/ B（有倾角测定）/ C（缺倾角或相位），覆盖全部天体"),
            ("数值验证", "地火会合周期 780 天（真实 779.9）；火星冲日 2025-01-16（差 0.11 天）；上海夏至昼长 14.1 h"),
        ], sz=1500),
    ])
    slides.append(els)

    # P14 对比分析（表格）
    rows = [
        ["本软件", "✓", "✓", "✓ 4参考系", "✓ 六类事件", "✓ 6375+", "✓ 6预设", "✓ A/B/C"],
        ["Celestia", "✓", "✗", "✓ 需插件", "✗", "✗", "✗", "✗"],
        ["NASA Eyes", "✗ 网页", "✗", "✓", "✗", "✗", "✗", "✗"],
        ["Stellarium", "✓", "✗", "✗", "✗", "✗", "✗", "✓"],
    ]
    els = content_page(14, "13  COMPARISON", "与现有工具对比", [
        table(_nid(), 700000, 2000000, 10790000,
              ["特性", "桌面离线", "Blender视角", "相对运动分析", "天象推演", "系外行星", "教学场景", "精度分级"],
              rows, col_ratio=[2.0, 1.0, 1.2, 1.35, 1.15, 1.15, 1.0, 1.0]),
        textbox(_nid(), "note", 700000, 4800000, 10790000, 600000,
                para(run("差异化定位：本软件是唯一同时提供“Blender 式交互 + 相对运动分析 + 天象推演 + 精度分级”的桌面工具",
                         1300, DIM, italic=True))),
    ])
    slides.append(els)

    # P15 演示效果
    els = content_page(15, "14  SHOWCASE", "软件运行效果", [
        card_grid(700000, 1950000, 10790000, 3600000, [
            ("截图 1：3D 太阳系全景", "八大行星真实轨道 + 主带小行星带点云 + 程序化星云背景 + 黄道网格（此处插入运行截图）"),
            ("截图 2：相对运动分析", "地火对比面板：3D 相对轨迹 + 距离/速度曲线 + 会合周期 780 天（此处插入截图）"),
            ("截图 3：地表视角 / 天象推演", "从火星表面仰望太阳，或天象推演表列出 2025 火星冲日（此处插入截图）"),
        ], cols=1),
    ])
    slides.append(els)

    # P16 现场演示脚本
    steps = [
        ("1 启动", "启动器选择 3D / 2D 视图（快捷键 3 / 2）"),
        ("2 漫游", "中键旋转 → 滚轮缩放 → Numpad 7 俯视"),
        ("3 对比", "右键地球/火星 → 加入对比 → 会合周期 780 天"),
        ("4 天象", "天象推演 → 火星冲日 → 点击跳转时间轴"),
        ("5 地表", "地表视角 → 站上火星表面仰望太阳"),
        ("6 教学", "教学场景 → 开普勒第二定律"),
    ]
    cards = [(t, d) for t, d in steps]
    els = content_page(16, "15  DEMO SCRIPT", "现场操作演示（60 秒）", [
        card_grid(700000, 1950000, 10790000, 4100000, cards, cols=3),
    ])
    slides.append(els)

    # P17 局限性与科学诚实性
    els = content_page(17, "16  HONESTY", "局限性与科学诚实性", [
        bullet_list(700000, 1950000, 10790000, [
            ("系外行星相位", "平近点角未测定，取 M(J2000)=0 可复现假设值，仅影响瞬时位置"),
            ("星历范围", "JPL 近似根数适用 1800–2050 年，超出主动弹出精度警告"),
            ("缺倾角", "约 60% 系外行星无倾角测定，标注 C 级精度，轨道方向为假设"),
            ("可视化比例", "默认半径放大 1000 倍，HUD 明确标注“距离为真实值”"),
            ("缺失数据", "一律显示“未知”，不伪造、不插值、不猜测；非地球天体经度零点取 W(J2000)=0 可复现假设"),
        ], sz=1500),
        textbox(_nid(), "attitude", 700000, 5300000, 10790000, 600000,
                para(run("态度：主动承认局限，比隐瞒更能获得评审认可", 1400, ACCENT, bold=True, italic=True))),
    ])
    slides.append(els)

    # P18 总结
    els = content_page(18, "17  SUMMARY", "总结与展望", [
        card_grid(700000, 1900000, 10790000, 2200000, [
            ("作品价值", "填补双行星相对运动分析与天象推演空白；Blender 式操作 + 3D/2D 双视口降低天文可视化门槛"),
            ("核心亮点", "真实数据 + 专业交互 + 科学诚实 + 教学场景，78 项验收自测全通过"),
        ], cols=2),
        textbox(_nid(), "future", 700000, 4400000, 10790000, 1300000,
                para(run("未来展望", 1500, ACCENT, bold=True), after=6)
                + para(run("▪ ", 1400, ACCENT, bold=True) + run("完整 6375+ 系外行星与 4781 恒星系已内置，后续持续同步 NASA 更新", 1400, TEXT), line=140, before=3)
                + para(run("▪ ", 1400, ACCENT, bold=True) + run("增加彗星 / 更多卫星与环系；中英双语；VR 沉浸式体验", 1400, TEXT), line=140, before=3)),
        textbox(_nid(), "thanks", 700000, 5850000, 10790000, 500000,
                para(run("致谢：华为云码道 CodeArts  |  JPL / NASA / ESA 公开数据", 1200, DIM))),
    ])
    slides.append(els)

    # P19 Q&A
    els = page_base(19)
    els.append(textbox(_nid(), "qa", 800000, 2700000, 10592000, 1200000,
                       para(run("Q & A", 6600, ACCENT, bold=True), align="ctr")))
    els.append(textbox(_nid(), "qasub", 800000, 4100000, 10592000, 600000,
                       para(run("感谢聆听，欢迎提问", 1800, TEXT), align="ctr")))
    slides.append(els)

    return slides


# ---------- OOXML 组装 ----------
def sp_tree(els):
    return ('<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
            '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
            '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
            + "".join(els) + '</p:spTree>')


def slide_xml(els):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
            'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
            '<p:cSld>' + sp_tree(els) + '</p:cSld>'
            '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>')


CONTENT_TYPES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                 '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                 '<Default Extension="xml" ContentType="application/xml"/>'
                 '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'
                 '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>'
                 '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>'
                 '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'
                 '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
                 '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
                 '{slide_overrides}</Types>')

ROOT_RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
             '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>'
             '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
             '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
             '</Relationships>')

CORE_PROPS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
              '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
              'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
              'xmlns:dcmitype="http://purl.org/dc/dcmitype/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
              '<dc:title>已知行星可视化 - 答辩PPT</dc:title>'
              '<dc:subject>2026 华为开发者大赛 · 上海理工大学站</dc:subject>'
              '<dc:creator>已知行星可视化团队</dc:creator>'
              '<cp:lastModifiedBy>华为云码道 CodeArts</cp:lastModifiedBy>'
              '</cp:coreProperties>')

APP_PROPS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" '
             'xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">'
             '<Application>Python stdlib OOXML builder（码道创新方案）</Application>'
             '<Slides>{n}</Slides></Properties>')


def build():
    slides = build_slides()
    n = len(slides)

    # presentation.xml
    sld_ids = "".join(f'<p:sldId id="{256 + i}" r:id="rId{i + 2}"/>' for i in range(n))
    presentation = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                    '<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
                    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
                    'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
                    f'<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
                    f'<p:sldIdLst>{sld_ids}</p:sldIdLst>'
                    f'<p:sldSz cx="{SW}" cy="{SH}"/><p:notesSz cx="6858000" cy="9144000"/>'
                    '</p:presentation>')

    pres_rels_items = ['<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>']
    for i in range(n):
        pres_rels_items.append(f'<Relationship Id="rId{i + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide{i + 1}.xml"/>')
    pres_rels_items.append(f'<Relationship Id="rId{n + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>')
    pres_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 + "".join(pres_rels_items) + '</Relationships>')

    slide_overrides = "".join(
        f'<Override PartName="/ppt/slides/slide{i + 1}.xml" '
        f'ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'
        for i in range(n))
    content_types = CONTENT_TYPES.replace("{slide_overrides}", slide_overrides)
    app_props = APP_PROPS.replace("{n}", str(n))

    theme = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Blender Dark">'
             '<a:themeElements><a:clrScheme name="BlenderDark">'
             f'<a:dk1><a:srgbClr val="{BG}"/></a:dk1><a:lt1><a:srgbClr val="{TEXT}"/></a:lt1>'
             f'<a:dk2><a:srgbClr val="{PANEL}"/></a:dk2><a:lt2><a:srgbClr val="{DIM}"/></a:lt2>'
             f'<a:accent1><a:srgbClr val="{ACCENT}"/></a:accent1><a:accent2><a:srgbClr val="{BLUE}"/></a:accent2>'
             '<a:accent3><a:srgbClr val="4FA3D1"/></a:accent3><a:accent4><a:srgbClr val="E8B04B"/></a:accent4>'
             '<a:accent5><a:srgbClr val="059669"/></a:accent5><a:accent6><a:srgbClr val="DC2626"/></a:accent6>'
             '<a:hlink><a:srgbClr val="4772B3"/></a:hlink><a:folHlink><a:srgbClr val="808080"/></a:folHlink>'
             '</a:clrScheme><a:fontScheme name="YaHeiUI">'
             '<a:majorFont><a:latin typeface="Microsoft YaHei UI"/><a:ea typeface="Microsoft YaHei UI"/><a:cs typeface=""/></a:majorFont>'
             '<a:minorFont><a:latin typeface="Microsoft YaHei UI"/><a:ea typeface="Microsoft YaHei UI"/><a:cs typeface=""/></a:minorFont>'
             '</a:fontScheme><a:fmtScheme name="Basic">'
             '<a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
             '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
             '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst>'
             '<a:lnStyleLst><a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
             '<a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
             '<a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst>'
             '<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle>'
             '<a:effectStyle><a:effectLst/></a:effectStyle>'
             '<a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>'
             '<a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
             '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
             '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst>'
             '</a:fmtScheme></a:themeElements></a:theme>')

    slide_master = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                    '<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
                    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
                    'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
                    '<p:cSld><p:bg><p:bgPr>'
                    f'<a:solidFill><a:srgbClr val="{BG}"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>'
                    '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
                    '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
                    '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld>'
                    '<p:clrMap bg1="dk1" tx1="lt1" bg2="dk2" tx2="lt2" accent1="accent1" accent2="accent2" '
                    'accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" '
                    'hlink="hlink" folHlink="folHlink"/>'
                    '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst></p:sldMaster>')

    master_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
                   '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>'
                   '</Relationships>')

    slide_layout = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                    '<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
                    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
                    'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
                    'type="blank" preserve="1"><p:cSld name="Blank">'
                    '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>'
                    '<p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
                    '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree></p:cSld>'
                    '<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>')

    layout_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                   '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                   '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/>'
                   '</Relationships>')

    slide_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                  '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                  '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
                  '</Relationships>')

    # XML 合法性预检
    for i, els in enumerate(slides):
        xml_str = slide_xml(els)
        minidom.parseString(xml_str)   # 解析失败会抛异常

    # 打包
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", ROOT_RELS)
        z.writestr("docProps/core.xml", CORE_PROPS)
        z.writestr("docProps/app.xml", app_props)
        z.writestr("ppt/presentation.xml", presentation)
        z.writestr("ppt/_rels/presentation.xml.rels", pres_rels)
        z.writestr("ppt/theme/theme1.xml", theme)
        z.writestr("ppt/slideMasters/slideMaster1.xml", slide_master)
        z.writestr("ppt/slideMasters/_rels/slideMaster1.xml.rels", master_rels)
        z.writestr("ppt/slideLayouts/slideLayout1.xml", slide_layout)
        z.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", layout_rels)
        for i, els in enumerate(slides):
            z.writestr(f"ppt/slides/slide{i + 1}.xml", slide_xml(els))
            z.writestr(f"ppt/slides/_rels/slide{i + 1}.xml.rels", slide_rels)

    size_kb = os.path.getsize(OUT) / 1024
    print(f"[OK] 生成 {OUT}")
    print(f"[OK] 共 {n} 页，文件大小 {size_kb:.1f} KB")
    print(f"[OK] 全部 {n} 页 XML 已通过 minidom 合法性校验")


if __name__ == "__main__":
    build()