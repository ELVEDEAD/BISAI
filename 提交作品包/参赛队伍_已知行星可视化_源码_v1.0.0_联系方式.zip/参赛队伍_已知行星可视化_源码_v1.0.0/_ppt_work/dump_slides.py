# -*- coding: utf-8 -*-
"""Dump text content of each slide (grouped by shape) for review."""
import os
import re
import sys
import xml.etree.ElementTree as ET

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
P = "http://schemas.openxmlformats.org/presentationml/2006/main"
ns = {"a": A, "p": P}

def slide_num(path):
    m = re.search(r"slide(\d+)\.xml$", path)
    return int(m.group(1)) if m else 0

def dump(path):
    tree = ET.parse(path)
    root = tree.getroot()
    print("=" * 70)
    print("FILE:", os.path.basename(path))
    print("=" * 70)
    for sp in root.iter():
        tag = sp.tag.split("}")[-1]
        if tag not in ("sp", "pic", "graphicFrame"):
            continue
        # gather all a:t under this shape
        texts = []
        for t in sp.iter("{%s}t" % A):
            texts.append(t.text or "")
        joined = "".join(texts)
        if joined.strip():
            print("[%s] %s" % (tag, joined))

if __name__ == "__main__":
    d = sys.argv[1]
    files = [os.path.join(d, f) for f in os.listdir(d) if f.endswith(".xml")]
    files.sort(key=slide_num)
    for f in files:
        dump(f)