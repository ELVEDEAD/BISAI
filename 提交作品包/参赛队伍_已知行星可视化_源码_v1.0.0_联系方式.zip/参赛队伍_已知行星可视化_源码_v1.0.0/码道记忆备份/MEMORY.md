# MEMORY

- [沙箱环境网络限制](sandbox_network_constraints.md) — pip/npm 不可用但 PyInstaller 6.10 预装；真实 .pptx 用纯标准库 zipfile+OOXML（spTree 不可双重嵌套）；打包 exe 需进程内 setrecursionlimit(30000)+排除torch/numba；沙箱超时常为误报先查日志