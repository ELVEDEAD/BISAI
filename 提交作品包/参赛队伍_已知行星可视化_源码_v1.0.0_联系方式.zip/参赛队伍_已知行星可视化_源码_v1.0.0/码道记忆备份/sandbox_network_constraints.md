---
name: 沙箱环境网络限制
description: 沙箱内 pip/npm 外网不可达，无法安装 python-pptx 等第三方包，需走离线/替代方案
type: project
---

沙箱环境中 **pip 外网不可达**（`Sandbox Network Error`），**npm 不存在**；但 **PyInstaller 6.10.0 已预装**（`python -c "import PyInstaller"` 可导入）。

**Why:** 沙箱网络隔离策略限制了对外部包仓库的访问，仅允许访问预装的 Python 包和 npm 缓存。

**How to apply:** 
- 需要生成 PPT/演示文稿时，**不能依赖 pip install / npm install**，必须走以下替代路线之一：
  1. 输出 Markdown 大纲文档（如 `答辩PPT大纲.md`），由用户在本地环境生成 pptx
  2. **方案 2 已验证可行（2026-10-08）**：纯 Python 标准库 `zipfile` + 手写 OOXML 构造真正的 .pptx。
     核心部件：`[Content_Types].xml`、`_rels/.rels`、`ppt/presentation.xml`、`ppt/theme/theme1.xml`、
     `slideMaster1.xml`、`slideLayout1.xml`、`slides/slideN.xml` 及各自的 `_rels`。
     关键坑：**slide 的 `<p:spTree>` 只能出现一次**（双重嵌套会导致 PowerPoint 打开报"需要修复"）；
     XML 属性用 `&amp;` 等实体转义；`minidom` 只能校验语法合法性，不能发现 schema 错误。
     参考实现：项目内 `_build_pptx.py`（生成）+ `_verify_pptx.py`（结构验证，24项）。
  3. 检查 `pip list` / `npm list -g --depth=0` 确认是否有可用的预装 pptx 包
- 本项目两种方案均已交付：方案 1（`答辩PPT大纲.md` 19页大纲）+ 方案 2（`已知行星可视化_答辩PPT.pptx` 19页真实文件，Blender深色主题）
- **PyInstaller 打包 exe（2026-10-08 验证成功）**：
  - 环境预装 PyInstaller 6.10.0，可直接用
  - 关键坑1：matplotlib/pandas 导入链触发 `RecursionError`，`PYTHON_RECURSION_LIMIT` 环境变量不生效，
    必须**进程内设置**：`python -c "import sys; sys.setrecursionlimit(30000); from PyInstaller.__main__ import run; run()" ...`
    或写脚本文件（项目内 `_build_exe_run.py`）
  - 关键坑2：site-packages 里装了 torch/numba/llvmlite/rich，hooks_contrib 会拉进来导致巨大且慢，
    必须 `--exclude-module torch --exclude-module numba --exclude-module llvmlite --exclude-module rich ...`
  - 关键坑3：bash 超长命令行（十几个参数）会"命令执行失败"，写成脚本文件执行
  - 关键坑4：沙箱经常**误报"执行时间超出沙箱限制"**但实际已完成——先查日志文件/输出目录再判断
  - 产物：136 MB onefile exe（含 PyQt5+matplotlib+numpy+pandas）