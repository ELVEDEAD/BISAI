"""
loader.py —— 天体数据统一加载层

设计要点（对应需求 4.3 / 4.4 / 4.5 节）：
- 统一坐标系：J2000 黄道坐标系。赤道坐标(RA/Dec)经黄赤交角旋转转入。
- 缺失字段一律为 None，界面显示"未知"，禁止伪造（科学诚实性）。
- 系外行星平近点角未测定：相位取 M(J2000)=0 的可复现假设值（非随机数），
  仅影响沿轨道瞬时位置，不影响轨道形状/周期；文档中明确说明。
- 数据校验：字段非法（NaN/负数等）视为缺失，不抛异常、不崩溃。
"""
import math
import os
import numpy as np
from dataclasses import dataclass, field

from core.constants import (PARSEC_AU, OBLIQUITY_J2000_DEG, DEG2RAD, J2000_JD,
                            GRADE_A, GRADE_B, GRADE_C, M_SUN_PER_EARTH, AU_KM)
from core.kepler import position_at_time, elements_to_position, solve_kepler, velocity_at_time
from core.time_system import datetime_to_jd
from data.solar_system import (SOLAR_PLANETS, SUN, SolarElements, MOONS, POLES,
                               ROTATION)
from data.exoplanets_builtin import BUILTIN_EXOPLANETS

G_SI = 6.67430e-11
M_SUN_KG = 1.98892e30
AU_M = 1.495978707e11

# ---------- 坐标转换（全软件统一） ----------
def _equatorial_to_ecliptic(ra_deg: float, dec_deg: float) -> np.ndarray:
    """赤道单位方向向量 → 黄道单位方向向量（J2000）"""
    ra, dec, eps = ra_deg * DEG2RAD, dec_deg * DEG2RAD, OBLIQUITY_J2000_DEG * DEG2RAD
    x = math.cos(dec) * math.cos(ra)
    y = math.cos(dec) * math.sin(ra) * math.cos(eps) + math.sin(dec) * math.sin(eps)
    z = -math.cos(dec) * math.sin(ra) * math.sin(eps) + math.sin(dec) * math.cos(eps)
    return np.array([x, y, z], dtype=np.float64)


def host_star_ecliptic_pos(ra_deg: float, dec_deg: float, dist_pc: float) -> np.ndarray:
    """宿主恒星三维位置（AU，J2000 黄道系）：方向 × 距离"""
    if ra_deg is None or dec_deg is None or dist_pc is None:
        return None
    return _equatorial_to_ecliptic(ra_deg, dec_deg) * (dist_pc * PARSEC_AU)


def _safe_float(v, lo=None, hi=None):
    """非法数值 → None（缺失），缺失显示'未知'，不伪造"""
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if math.isnan(f) or math.isinf(f):
        return None
    if lo is not None and f < lo:
        return None
    if hi is not None and f > hi:
        return None
    return f


BODY_TYPE_LABELS = {
    "star": "恒星",
    "planet_solar": "行星（太阳系）",
    "dwarf": "矮行星（太阳系）",
    "moon": "天然卫星",
    "planet_exo": "系外行星",
}


@dataclass
class SystemGroup:
    """恒星系（系群）：一颗宿主恒星及其行星。

    太阳系为一特例（is_solar=True，含恒星「太阳」与天然卫星）。
    用于左侧天体树按「恒星系」归类展示，以及恒星系概览面板。
    """
    host: str
    is_solar: bool = False
    star: object = None                            # 恒星 Body（太阳系为太阳）
    planets: list = field(default_factory=list)    # 行星 / 矮行星
    moons: list = field(default_factory=list)      # 天然卫星（仅太阳系）
    spec: str = ""                                 # 恒星光度型（如 G2V、M8V）
    dist_pc: float = None                          # 恒星系距地球距离（pc）
    planet_count: int = None                       # 官方已确认行星数（sy_pnum）
    star_count: int = None                         # 系统恒星数（sy_snum）
    host_teff: float = None                        # 宿主恒星有效温度（K）
    host_radius_solar: float = None                # 宿主恒星半径（R☉）
    host_mass_solar: float = None                  # 宿主恒星质量（M☉）
    host_lum: float = None                         # 宿主星光度（log L☉）

    @property
    def n_planets(self) -> int:
        """本恒星系收录的成员行星数"""
        return len(self.planets)


@dataclass
class Body:
    """统一天体模型：太阳系行星 / 矮行星 / 恒星 / 系外行星"""
    name: str
    body_type: str
    grade: str                       # 精度等级 A/B/C
    color: tuple
    en_name: str = ""
    host: str = ""                   # 宿主恒星（太阳系行星为"太阳"）
    # —— JPL 近似根数（太阳系） ——
    elements: SolarElements = None
    # —— 开普勒根数（系外行星 / 通用） ——
    a_au: float = None
    e: float = None
    incl_deg: float = None
    period_days: float = None
    # —— 物理参数 ——
    radius_km: float = None
    mass_earth: float = None
    # —— 发现信息 ——
    disc_year: int = None
    method: str = ""
    data_source: str = ""            # 数据来源标注（详情面板展示）
    # —— 系外行星 / 恒星位置 ——
    dist_pc: float = None
    ra_deg: float = None
    dec_deg: float = None
    host_pos: np.ndarray = None      # 宿主恒星黄道坐标（AU）
    assumed_phase: bool = False      # 平近点角为假设值（M(J2000)=0）
    visible_mag: float = None        # 恒星视星等（背景渲染用）
    # —— 宿主恒星（系外行星所属恒星系） ——
    host_teff: float = None          # 宿主恒星有效温度（K）
    host_radius_solar: float = None  # 宿主恒星半径（R☉）
    host_mass_solar: float = None    # 宿主恒星质量（M☉）
    host_spec: str = ""              # 宿主恒星光度型（如 G2V）
    host_lum: float = None           # 宿主星光度（log L☉）
    host_age: float = None           # 宿主星年龄（Gyr）
    host_met: float = None           # 宿主星金属丰度 [Fe/H]（dex）
    sys_planet_count: int = None     # 该系统已确认行星数
    sys_star_count: int = None       # 该系统恒星数
    # —— 行星附加物理量 ——
    eq_temp: float = None            # 平衡温度（K）
    density: float = None            # 密度（g/cm³）
    # —— 天然卫星 ——
    parent: object = field(default=None, repr=False, compare=False)  # 母天体 Body
    parent_name: str = ""            # 母天体名称（地球/木星/…）
    plane: str = "equator"           # 卫星轨道面参考：equator=母行星赤道面 / ecliptic=黄道面
    retro: bool = False              # 逆行轨道（如海卫一）
    # —— 自转 ——
    rot_period_days: float = None    # 自转周期（恒星日，天；负值=逆行自转）
    pole_ecl: np.ndarray = None      # 自转轴方向（J2000 黄道系单位向量）

    # ---------- 周期 ----------
    @property
    def period(self) -> float:
        """公转周期（天）；太阳系行星由半长轴推算（开普勒第三定律），系外行星用实测值"""
        if self.period_days:
            return self.period_days
        if self.a_au and self.body_type in ("planet_solar", "dwarf"):
            return 365.25 * self.a_au ** 1.5
        return None

    @property
    def mass_solar(self):
        if self.mass_earth is None:
            return None
        return self.mass_earth / M_SUN_PER_EARTH

    # ---------- 自转 ----------
    @property
    def rotation_direction(self):
        """自转方向：顺行 / 逆行（缺数据返回 None）"""
        if self.rot_period_days is None:
            return None
        return "逆行" if self.rot_period_days < 0 else "顺行"

    def orbit_normal(self) -> np.ndarray:
        """轨道面法向（J2000 黄道系单位向量）。

        行星/矮行星：由轨道倾角 i 与升交点经度 Ω 构造；
        天然卫星：取母行星赤道面（或黄道面）法向；系外行星：倾角已知时按 Ω=0 近似。
        缺参数返回 None（不伪造）。
        """
        if self.body_type in ("planet_solar", "dwarf") and self.elements is not None:
            i = self.elements.i * DEG2RAD
            Om = self.elements.Omega * DEG2RAD
            n = np.array([math.sin(i) * math.sin(Om),
                          -math.sin(i) * math.cos(Om),
                          math.cos(i)])
            return n / max(float(np.linalg.norm(n)), 1e-15)
        if self.body_type == "moon":
            u, v = self._moon_plane_basis()
            n = np.cross(u, v)
            return n / max(float(np.linalg.norm(n)), 1e-15)
        if self.incl_deg is not None:
            i = self.incl_deg * DEG2RAD
            return np.array([0.0, -math.sin(i), math.cos(i)])
        return None

    @property
    def axial_tilt_deg(self):
        """转轴倾角（度）：自转轴与轨道面法线的夹角。

        取向约定（与天文教科书一致）：顺行自转取 <90° 的一侧，逆行自转取 >90°
        的一侧。自转轴方向取 IAU WGCCRE 极轴（RA/Dec）转入黄道系；缺极轴或
        轨道面法向时返回 None。
        """
        if self.pole_ecl is None:
            return None
        h = self.orbit_normal()
        if h is None:
            return None
        p = self.pole_ecl / max(float(np.linalg.norm(self.pole_ecl)), 1e-15)
        c = float(np.dot(p, h))
        ang = math.degrees(math.acos(max(-1.0, min(1.0, c))))
        retro = bool(self.rot_period_days is not None and self.rot_period_days < 0)
        if (ang > 90.0) != retro:        # 取向与自转方向不一致时取另一侧
            ang = 180.0 - ang
        return ang

    def spin_angle_at_jd(self, jd: float) -> float:
        """自转相位（弧度，随时间单调推进；逆行自转为负向）。

        相位零点取可复现假设值 W(J2000)=0（IAU 本初子午线角的常数项未收录），
        只影响子午线当前朝向，不影响自转速率/方向。
        """
        if not self.rot_period_days:
            return 0.0
        return 2.0 * math.pi * (jd - J2000_JD) / self.rot_period_days

    # ---------- 位置 ----------
    def position_at_jd(self, jd: float) -> np.ndarray:
        """三维位置（AU，J2000 黄道系）。恒星返回宿主位置/原点。"""
        if self.body_type == "star":
            return self.host_pos.copy() if self.host_pos is not None else np.zeros(3)
        if self.body_type in ("planet_solar", "dwarf"):
            T = (jd - J2000_JD) / 36525.0
            el = self.elements
            return position_at_time(el.a, el.a_dot, el.e, el.e_dot, el.i, el.i_dot,
                                    el.L, el.L_dot, el.varpi, el.varpi_dot,
                                    el.Omega, el.Omega_dot, T)
        if self.body_type == "moon":
            # 天然卫星：母行星位置 + 相对母行星的开普勒轨道
            base = (self.parent.position_at_jd(jd)
                    if self.parent is not None else np.zeros(3))
            return base + self._moon_relative_pos(jd)
        # 系外行星：宿主星位置 + 相对开普勒轨道
        if self.host_pos is None:
            return np.zeros(3)
        return self.host_pos + self._relative_pos(jd)

    def _moon_plane_basis(self):
        """卫星轨道面的正交基 (u, v)（J2000 黄道系单位向量）。

        母行星赤道面：由 POLES 的真实极轴（赤道坐标 RA/Dec）转入黄道系作为法向；
        月球取黄道面。轨道面近似约定见 solar_system.MOONS 注释。
        """
        if self.plane == "ecliptic" or self.parent is None:
            return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])
        pole = POLES.get(self.parent.name)
        if pole is None:
            return np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0])
        n = _equatorial_to_ecliptic(pole[0], pole[1])
        n = n / max(float(np.linalg.norm(n)), 1e-15)
        ref = np.array([0.0, 0.0, 1.0])
        if abs(float(np.dot(n, ref))) > 0.9:
            ref = np.array([1.0, 0.0, 0.0])
        u = np.cross(ref, n)
        u = u / max(float(np.linalg.norm(u)), 1e-15)
        v = np.cross(n, u)
        if self.retro:                     # 逆行轨道：反转轨道方向
            v = -v
        return u, v

    def _moon_relative_pos(self, jd: float) -> np.ndarray:
        """相对母行星的位置（AU）。相位取可复现假设值 M(J2000)=0。"""
        if not self.a_au:
            return np.zeros(3)
        e = self.e if self.e is not None else 0.0
        p = self.period_days or 1.0
        M = (2.0 * math.pi / p) * (jd - J2000_JD)
        E = solve_kepler(M, e)
        xv = self.a_au * (math.cos(E) - e)
        yv = self.a_au * math.sqrt(max(1.0 - e * e, 0.0)) * math.sin(E)
        u, v = self._moon_plane_basis()
        return xv * u + yv * v

    def _relative_pos(self, jd: float) -> np.ndarray:
        """相对宿主星的开普勒位置（AU）"""
        if not self.a_au:
            return np.zeros(3)
        e = self.e if self.e is not None else 0.0
        i = self.incl_deg if self.incl_deg is not None else 0.0
        p = self.period
        if not p:
            # 无周期则由半长轴近似（绕 1 M☉ 恒星），缺失时标"未知"
            p = 365.25 * (self.a_au ** 1.5)
        n = 2.0 * math.pi / p
        M = n * (jd - J2000_JD)          # 可复现假设：M(J2000)=0
        return elements_to_position(self.a_au, e, i, 0.0, 0.0, M)

    # ---------- 速度（km/s，解析） ----------
    def velocity_at_jd(self, jd: float) -> np.ndarray:
        """速度（km/s）。系外行星缺质量按 1 M☉ 中心估算，标注于文档。"""
        if self.body_type == "star":
            return np.zeros(3)
        if self.body_type == "moon":
            # 卫星：对位置做中心差分（轨道面由母行星极轴定向，解析式不便直接套用）
            dt = 0.01
            p1 = self.position_at_jd(jd - dt)
            p2 = self.position_at_jd(jd + dt)
            return (p2 - p1) * (AU_KM / (2.0 * dt * 86400.0))
        if self.body_type in ("planet_solar", "dwarf"):
            el = self.elements
            T = (jd - J2000_JD) / 36525.0
            a = el.a + el.a_dot * T
            e = el.e + el.e_dot * T
            L = (el.L + el.L_dot * T) % 360.0
            varpi = (el.varpi + el.varpi_dot * T) % 360.0
            M = (L - varpi) * DEG2RAD
            omega = varpi - (el.Omega + el.Omega_dot * T)
            return velocity_at_time(a, e, el.i + el.i_dot * T,
                                    el.Omega + el.Omega_dot * T, omega, M,
                                    self.period or 365.25 * a ** 1.5,
                                    M_SUN_KG)
        # 系外行星：相对宿主星速度（恒星自行忽略）
        if not self.a_au:
            return np.zeros(3)
        e = self.e if self.e is not None else 0.0
        i = self.incl_deg if self.incl_deg is not None else 0.0
        p = self.period or 365.25 * (self.a_au ** 1.5)
        M = (2.0 * math.pi / p) * (jd - J2000_JD)
        return velocity_at_time(self.a_au, e, i, 0.0, 0.0, M, p, 0.0)

    _host_mass_solar = 1.0     # 中心天体质量（缺恒星质量数据时按 1 M☉）

    # ---------- 详情字段（缺失返回"未知"） ----------
    def field_unknown(self, v, fmt="{:.6g}", suffix=""):
        if v is None:
            return "未知"
        try:
            return fmt.format(v) + suffix
        except (TypeError, ValueError):
            return "未知"


# ---------- 太阳系加载 ----------
def load_solar_system() -> list:
    bodies = []
    sun = Body(name=SUN["name"], body_type="star", grade=GRADE_A,
               color=SUN["color"], en_name=SUN["en"],
               radius_km=SUN["radius_km"], mass_earth=SUN["mass_earth"],
               host_pos=np.zeros(3), data_source="坐标系原点（日心）",
               method="—")
    bodies.append(sun)
    for name, d in SOLAR_PLANETS.items():
        el = d["elements"]
        btype = "dwarf" if name == "冥王星" else "planet_solar"
        pole = POLES.get(name)
        pole_ecl = _equatorial_to_ecliptic(pole[0], pole[1]) if pole else None
        bodies.append(Body(
            name=name, body_type=btype, grade=GRADE_A, color=d["color"],
            en_name=d["en"], host="太阳", elements=el,
            a_au=el.a, e=el.e, incl_deg=el.i,
            radius_km=d["radius_km"], mass_earth=d["mass_earth"],
            disc_year=d["disc_year"], method=d["method"],
            rot_period_days=ROTATION.get(name), pole_ecl=pole_ecl,
            data_source="JPL 近似轨道根数（Standish，1800–2050 适用）",
        ))
    return bodies


# ---------- 天然卫星加载 ----------
def load_moons(parents_by_name: dict) -> list:
    """加载主要天然卫星（挂到母行星 Body 上，位置=母行星 + 相对开普勒轨道）

    轨道与物理参数为真实值；轨道面近似取母行星赤道面（由真实极轴定向），
    月球取黄道面；沿轨道相位为可复现假设值 M(J2000)=0。
    """
    out = []
    for name, d in MOONS.items():
        parent = parents_by_name.get(d["parent"])
        if parent is None:
            continue
        pole = POLES.get(name)
        pole_ecl = _equatorial_to_ecliptic(pole[0], pole[1]) if pole else None
        out.append(Body(
            name=name, body_type="moon", grade=GRADE_B, color=d["color"],
            en_name=d["en"], host="太阳", parent=parent, parent_name=d["parent"],
            a_au=d["a_km"] / AU_KM, e=d["e"], incl_deg=d.get("incl_deg"),
            period_days=d["period_days"], radius_km=d["radius_km"],
            mass_earth=d.get("mass_earth"), plane=d.get("plane", "equator"),
            retro=bool(d.get("retro", False)), assumed_phase=True,
            rot_period_days=ROTATION.get(name), pole_ecl=pole_ecl,
            disc_year=d.get("disc_year"), method=d.get("method", "望远镜观测"),
            data_source=("NASA/JPL 卫星轨道与物理参数（真实值）；轨道面近似取母行星"
                         "赤道面，相位为可复现假设值 M(J2000)=0"),
        ))
    return out


# ---------- 系外行星加载（优先本地 CSV 完整目录，否则内置真实子集） ----------
EXO_CSV_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "exoplanets.csv")


def load_exoplanets() -> list:
    if os.path.exists(EXO_CSV_PATH):
        try:
            bodies = _load_exo_csv(EXO_CSV_PATH)
            if bodies:
                return bodies
        except Exception:
            pass   # CSV 损坏时回退内置子集，给出提示日志
    return _load_builtin_exoplanets()


def _load_builtin_exoplanets() -> list:
    bodies = []
    for d in BUILTIN_EXOPLANETS:
        ra, dec, dist = d.get("ra"), d.get("dec"), d.get("dist_pc")
        hpos = host_star_ecliptic_pos(ra, dec, dist) if dist else None
        # 精度分级：凌星行星有倾角→B；RV/成像无倾角→C
        has_i = d.get("incl") is not None
        grade = GRADE_B if (has_i and hpos is not None) else GRADE_C
        bodies.append(Body(
            name=d["name"], body_type="planet_exo", grade=grade,
            color=tuple(d.get("color", (0.85, 0.75, 0.55))),
            host=d["host"], a_au=d.get("a"), e=d.get("ecc"),
            incl_deg=d.get("incl"), period_days=d.get("period"),
            radius_km=(d["radius_earth"] * 6371.0) if d.get("radius_earth") else None,
            mass_earth=d.get("mass_earth"),
            disc_year=d.get("year"), method=d.get("method", "未知"),
            dist_pc=dist, ra_deg=ra, dec_deg=dec, host_pos=hpos,
            assumed_phase=True,
            data_source="NASA Exoplanet Archive（内置精选子集）",
        ))
    return bodies


def _load_exo_csv(path: str) -> list:
    """加载 NASA Exoplanet Archive 官方完整 CSV（列名见 download_exoplanets.py）

    优先使用 pscomppars 复合列（pl_bmasse/pl_rade，地球单位；含宿主恒星参数）；
    若为旧版 ps 列（pl_bmassj/pl_radj，木星单位）则自动换算，保证兼容。
    """
    import pandas as pd
    df = pd.read_csv(path, comment="#", low_memory=False)
    colmap = {
        "pl_name": "name", "hostname": "host", "pl_orbper": "period",
        "pl_orbsmax": "a", "pl_orbeccen": "ecc", "pl_orbincl": "incl",
        "pl_bmasse": "mass_earth", "pl_rade": "radius_earth",
        "pl_bmassj": "mass_jup", "pl_radj": "radius_jup",
        "pl_dens": "density", "pl_eqt": "eq_temp",
        "disc_year": "year", "discoverymethod": "method",
        "sy_dist": "dist_pc", "ra": "ra", "dec": "dec",
        "sy_snum": "sys_star_count", "sy_pnum": "sys_planet_count",
        "st_teff": "host_teff", "st_rad": "host_radius_solar",
        "st_mass": "host_mass_solar", "st_spectype": "host_spec",
        "st_lum": "host_lum", "st_age": "host_age", "st_met": "host_met",
    }
    cols = {k: v for k, v in colmap.items() if k in df.columns}
    n = len(df)
    recs = {v: df[k].tolist() for k, v in cols.items()}
    bodies = []
    for i in range(n):
        g = lambda key: recs.get(key, [None] * n)[i]
        name = g("name")
        if not isinstance(name, str) or not name.strip():
            continue
        # 质量（地球质量）：优先 pl_bmasse，其次 pl_bmassj×317.8
        mass_earth = _safe_float(g("mass_earth"), 0)
        if mass_earth is None:
            mj = _safe_float(g("mass_jup"), 0)
            mass_earth = mj * 317.8 if mj is not None else None
        # 半径（km）：优先 pl_rade，其次 pl_radj
        radius_km = _safe_float(g("radius_earth"), 0)
        if radius_km is not None:
            radius_km *= 6371.0
        else:
            rj = _safe_float(g("radius_jup"), 0)
            radius_km = rj * 69911.0 if rj is not None else None
        ra = _safe_float(g("ra"), 0, 360)
        dec = _safe_float(g("dec"), -90, 90)
        dist = _safe_float(g("dist_pc"), 0)
        hpos = host_star_ecliptic_pos(ra, dec, dist) if dist else None
        has_i = _safe_float(g("incl"), 0, 180) is not None
        grade = GRADE_B if (has_i and hpos is not None) else GRADE_C
        spec = g("host_spec")
        bodies.append(Body(
            name=name.strip(), body_type="planet_exo", grade=grade,
            color=(0.85, 0.75, 0.55), host=str(g("host") or "未知"),
            a_au=_safe_float(g("a"), 0), e=_safe_float(g("ecc"), 0, 1),
            incl_deg=_safe_float(g("incl"), 0, 180),
            period_days=_safe_float(g("period"), 0),
            radius_km=radius_km, mass_earth=mass_earth,
            disc_year=_safe_float(g("year"), 1900, 2100),
            method=str(g("method") or "未知"),
            dist_pc=dist, ra_deg=ra, dec_deg=dec, host_pos=hpos,
            assumed_phase=True,
            host_teff=_safe_float(g("host_teff"), 0),
            host_radius_solar=_safe_float(g("host_radius_solar"), 0),
            host_mass_solar=_safe_float(g("host_mass_solar"), 0),
            host_spec=(str(spec) if isinstance(spec, str) else ""),
            host_lum=_safe_float(g("host_lum")),
            host_age=_safe_float(g("host_age"), 0),
            host_met=_safe_float(g("host_met")),
            sys_planet_count=_safe_float(g("sys_planet_count"), 0),
            sys_star_count=_safe_float(g("sys_star_count"), 0),
            eq_temp=_safe_float(g("eq_temp"), 0),
            density=_safe_float(g("density"), 0),
            data_source="NASA Exoplanet Archive（官方完整目录 pscomppars）",
        ))
    return bodies


def load_all_bodies() -> tuple:
    """加载全部天体：太阳系（含天然卫星）+ 系外行星。返回 (bodies, stats)"""
    solar = load_solar_system()
    parents = {b.name: b for b in solar}
    moons = load_moons(parents)
    exo = load_exoplanets()
    stats = {
        "solar_count": len(solar),
        "moon_count": len(moons),
        "exo_count": len(exo),
        "exo_source": "CSV 完整目录" if os.path.exists(EXO_CSV_PATH) else "内置精选子集",
    }
    return solar + moons + exo, stats


# ---------- 恒星系（系群）分组 ----------
def group_by_system(bodies) -> list:
    """把全部天体按「恒星系（系群）」归类：一颗宿主恒星 + 其行星。

    - 太阳系（is_solar=True）：太阳 + 8 行星 + 矮行星 + 天然卫星，恒为第 1 项；
    - 系外行星按宿主恒星（hostname）归并；同一宿主星的全部行星合成一个恒星系；
    - 排序：行星数降序 → 名称升序（多行星系统靠前，便于浏览 TRAPPIST-1 等典型系）。

    返回 SystemGroup 列表（不含任何随机性，纯确定性归并）。
    """
    sun = None
    solar_planets, solar_moons = [], []
    exo = {}
    for b in bodies:
        if b.body_type == "star":
            sun = b
        elif b.body_type == "moon":
            solar_moons.append(b)
        elif b.body_type in ("planet_solar", "dwarf"):
            solar_planets.append(b)
        elif b.body_type == "planet_exo":
            exo.setdefault(b.host or "未知宿主", []).append(b)

    groups = []
    if sun is not None or solar_planets:
        solar_planets.sort(key=lambda b: (b.a_au is None, b.a_au or 0.0))
        groups.append(SystemGroup(
            host="太阳", is_solar=True, star=sun,
            planets=solar_planets, moons=solar_moons,
            spec="G2V", planet_count=len(solar_planets), star_count=1,
            host_teff=5772.0, host_radius_solar=1.0, host_mass_solar=1.0))

    exo_groups = []
    for host, plist in exo.items():
        plist.sort(key=lambda b: (b.a_au is None, b.a_au or 0.0))
        first = plist[0]
        exo_groups.append(SystemGroup(
            host=host, is_solar=False, planets=plist,
            spec=first.host_spec or "", dist_pc=first.dist_pc,
            planet_count=first.sys_planet_count, star_count=first.sys_star_count,
            host_teff=first.host_teff, host_radius_solar=first.host_radius_solar,
            host_mass_solar=first.host_mass_solar, host_lum=first.host_lum))
    exo_groups.sort(key=lambda g: (-g.n_planets, g.host.lower()))
    return groups + exo_groups