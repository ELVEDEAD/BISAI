"""
asteroid_belt.py —— 主带小行星点云数据生成

按真实主带分布随机生成 N 颗小行星的轨道根数：
    - 半长轴 2.06–3.28 AU，并挖掉主要柯克伍德空隙（与小行星数密度低谷对应）
    - 偏心率 β 分布（多数接近圆轨道）
    - 倾角以黄道面为中心聚集，上限约 24°

位置不在这里计算：由 GPU 顶点着色器按开普勒方程实时求解，
CPU 每帧零开销（见 scene/viewport.py 的 VS_BELT）。

输出 (N, 10) float32，每行：
    [a, e, i, Ω, ω, M0, r, g, b, size]
    长度单位 AU；角度单位弧度
"""
import numpy as np

BELT_MAX = 50000                                  # 预生成上限
KIRKWOOD_GAPS = (2.06, 2.50, 2.82, 2.95, 3.27)    # 4:1 / 3:1 / 5:2 / 7:3 / 2:1 共振
KIRKWOOD_WIDTHS = (0.020, 0.035, 0.030, 0.025, 0.030)
A_MIN, A_MAX = 2.06, 3.28


def _semi_major(rng, count: int) -> np.ndarray:
    """主带半长轴采样：区间内均匀分布 + 柯克伍德空隙拒绝采样"""
    out = []
    need = count
    for _ in range(200):
        if need <= 0:
            break
        cand = rng.uniform(A_MIN, A_MAX, max(need * 2, 64))
        keep = np.ones_like(cand)
        for gap, width in zip(KIRKWOOD_GAPS, KIRKWOOD_WIDTHS):
            keep *= 1.0 - 0.95 * np.exp(-((cand - gap) / width) ** 2)
        acc = cand[rng.random(cand.size) < keep]
        if acc.size == 0:
            continue
        out.append(acc[:need])
        need -= int(min(need, acc.size))
    if need > 0:                                   # 极端兜底，保证数量
        out.append(rng.uniform(A_MIN, A_MAX, need))
    return np.concatenate(out)[:count]


def generate_belt(count: int = BELT_MAX, seed: int = 20261008) -> np.ndarray:
    """生成主带小行星轨道根数点云（可复现：固定随机种子）"""
    rng = np.random.default_rng(seed)

    a = _semi_major(rng, count)
    e = np.clip(rng.beta(1.6, 5.0, count) * 0.55, 0.0, 0.32)
    inc_deg = np.clip(np.abs(rng.normal(0.0, 8.5, count)), 0.0, 24.0)
    Omega = rng.uniform(0.0, 2.0 * np.pi, count)
    omega = rng.uniform(0.0, 2.0 * np.pi, count)
    M0 = rng.uniform(-np.pi, np.pi, count)

    # 颜色：S 型（偏红褐）与 C 型（偏暗灰）约各半，加少量亮度扰动
    s_type = rng.random(count)[:, None] < 0.5
    base = np.where(s_type, np.array([0.72, 0.62, 0.48]),
                    np.array([0.46, 0.46, 0.50]))
    color = np.clip(base + rng.normal(0.0, 0.05, (count, 3)), 0.15, 1.0)

    # 点大小：幂律分布——绝大多数 1px，极少数更大更亮
    size = 1.0 + 2.2 * rng.random(count) ** 8

    data = np.empty((count, 10), dtype=np.float32)
    data[:, 0] = a
    data[:, 1] = e
    data[:, 2] = np.radians(inc_deg)
    data[:, 3] = Omega
    data[:, 4] = omega
    data[:, 5] = M0
    data[:, 6:9] = color
    data[:, 9] = size
    return data
