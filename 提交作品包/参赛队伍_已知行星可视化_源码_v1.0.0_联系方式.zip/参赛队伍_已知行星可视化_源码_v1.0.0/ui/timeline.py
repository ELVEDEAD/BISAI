"""
timeline.py —— 底部时间轴控件（模块 I）

功能：
- 播放/暂停/倒放按钮
- 9 档倍速滑块（实时×1 ~ 100年/秒）
- 当前仿真日期显示 + 日期跳转输入
- JPL 星历适用范围指示（1800–2050）
- 与 SimulationClock 双向绑定
"""
from datetime import datetime

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (QWidget, QHBoxLayout, QVBoxLayout, QPushButton,
                             QSlider, QLabel, QLineEdit, QFrame)

from core.time_system import SimulationClock, SPEED_STEPS, jd_to_datetime, datetime_to_jd
from data.solar_system import EPHEMERIS_VALID_YEARS
from ui.style import TEXT_MAIN, TEXT_DIM, ACCENT, BG_PANEL


class Timeline(QWidget):
    """底部时间轴：播放控制 + 倍速 + 日期跳转"""
    dateChanged = pyqtSignal(float)   # jd 变化（跳转时发射）

    def __init__(self, clock: SimulationClock, parent=None):
        super().__init__(parent)
        self.clock = clock
        self.setFixedHeight(56)
        self._build_ui()
        self._refresh()

    def _build_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(8)

        # 播放/暂停
        self.btn_play = QPushButton("▶")
        self.btn_play.setFixedWidth(36)
        self.btn_play.setToolTip("播放 / 暂停（空格键）")
        self.btn_play.clicked.connect(self._toggle_play)
        layout.addWidget(self.btn_play)

        # 倒放
        self.btn_reverse = QPushButton("◀◀")
        self.btn_reverse.setFixedWidth(36)
        self.btn_reverse.setToolTip("倒放 / 正放切换")
        self.btn_reverse.clicked.connect(self._toggle_reverse)
        layout.addWidget(self.btn_reverse)

        # 倍速滑块
        self.slider_speed = QSlider(Qt.Horizontal)
        self.slider_speed.setMinimum(0)
        self.slider_speed.setMaximum(len(SPEED_STEPS) - 1)
        self.slider_speed.setValue(self.clock.speed_index)
        self.slider_speed.setFixedWidth(160)
        self.slider_speed.setToolTip("时间倍速")
        self.slider_speed.valueChanged.connect(self._on_speed_changed)
        layout.addWidget(self.slider_speed)

        self.lbl_speed = QLabel(SPEED_STEPS[self.clock.speed_index][0])
        self.lbl_speed.setFixedWidth(80)
        self.lbl_speed.setStyleSheet(f"color: {TEXT_DIM};")
        layout.addWidget(self.lbl_speed)

        # 分隔线
        sep = QFrame()
        sep.setFrameShape(QFrame.VLine)
        sep.setStyleSheet("color: #252525;")
        layout.addWidget(sep)

        # 当前日期
        self.lbl_date = QLabel("")
        self.lbl_date.setStyleSheet(f"color: {TEXT_MAIN}; font-size: 13px; font-weight: bold;")
        self.lbl_date.setMinimumWidth(120)
        layout.addWidget(self.lbl_date)

        # 日期跳转
        layout.addWidget(QLabel("跳转:"))
        self.edit_jump = QLineEdit()
        self.edit_jump.setPlaceholderText("YYYY-MM-DD")
        self.edit_jump.setMaximumWidth(120)
        self.edit_jump.returnPressed.connect(self._jump_to_date)
        layout.addWidget(self.edit_jump)

        self.btn_jump = QPushButton("跳转")
        self.btn_jump.clicked.connect(self._jump_to_date)
        layout.addWidget(self.btn_jump)

        # 今天按钮
        self.btn_today = QPushButton("今天")
        self.btn_today.setToolTip("跳转到当前真实日期")
        self.btn_today.clicked.connect(self._jump_today)
        layout.addWidget(self.btn_today)

        layout.addStretch()

        # 星历范围提示
        self.lbl_ephem = QLabel("")
        self.lbl_ephem.setStyleSheet(f"color: {TEXT_DIM}; font-size: 10px;")
        layout.addWidget(self.lbl_ephem)

    # ---------- 操作 ----------
    def _toggle_play(self):
        self.clock.toggle_play()
        self._refresh()

    def _toggle_reverse(self):
        self.clock.reverse()
        self._refresh()

    def _on_speed_changed(self, idx):
        self.clock.speed_index = idx
        self.lbl_speed.setText(
            ("-" if self.clock.direction < 0 else "") + SPEED_STEPS[idx][0])
        self._refresh_ephem()

    def _jump_to_date(self):
        text = self.edit_jump.text().strip()
        try:
            dt = datetime.strptime(text, "%Y-%m-%d")
            self.clock.jump_to_datetime(dt)
            self.dateChanged.emit(self.clock.jd)
            self._refresh()
        except ValueError:
            self.edit_jump.setStyleSheet("border: 1px solid #e87d0d;")
            self.edit_jump.setText("")
            self.edit_jump.setPlaceholderText("格式: YYYY-MM-DD")

    def _jump_today(self):
        self.clock.jump_to_datetime(datetime.now())
        self.dateChanged.emit(self.clock.jd)
        self._refresh()

    # ---------- 刷新 ----------
    def _refresh(self):
        if self.clock.playing:
            self.btn_play.setText("▶")
            self.btn_play.setToolTip("暂停（空格键）")
        else:
            self.btn_play.setText("❚❚")
            self.btn_play.setToolTip("播放（空格键）")
        sign = "-" if self.clock.direction < 0 else ""
        self.lbl_speed.setText(sign + SPEED_STEPS[self.clock.speed_index][0])
        self.slider_speed.blockSignals(True)
        self.slider_speed.setValue(self.clock.speed_index)
        self.slider_speed.blockSignals(False)
        self._refresh_date()
        self._refresh_ephem()

    def _refresh_date(self):
        dt = self.clock.now_datetime()
        self.lbl_date.setText(dt.strftime("%Y-%m-%d"))

    def _refresh_ephem(self):
        year = self.clock.now_datetime().year
        lo, hi = EPHEMERIS_VALID_YEARS
        if year < lo or year > hi:
            self.lbl_ephem.setText(f"⚠ 超出星历范围 ({lo}–{hi})")
            self.lbl_ephem.setStyleSheet(f"color: {ACCENT}; font-size: 10px;")
        else:
            self.lbl_ephem.setText(f"星历范围: {lo}–{hi}")
            self.lbl_ephem.setStyleSheet(f"color: {TEXT_DIM}; font-size: 10px;")

    def tick(self):
        """由主窗口定时器调用：刷新日期显示（不重发信号）"""
        self._refresh_date()
        self._refresh_ephem()