"""
guide.py —— 新手引导教程（模块 N）

首次启动时引导用户完成完整操作流程：
  1. 欢迎介绍
  2. 视角漫游（中键旋转/滚轮缩放）
  3. 搜索天体
  4. 选中两颗行星
  5. 查看相对运动分析

使用半透明覆盖层 + 步骤提示卡片，可随时跳过或回看。
"""
import os
import json

from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtWidgets import (QWidget, QDialog, QVBoxLayout, QHBoxLayout,
                             QLabel, QPushButton, QFrame, QCheckBox)

from ui.style import TEXT_MAIN, TEXT_DIM, ACCENT, BG_PANEL, BG_PANEL_LIGHT

GUIDE_FLAG_FILE = os.path.normpath(
    os.path.join(os.path.dirname(os.path.abspath(__file__)),
                 "..", ".guide_completed"))


GUIDE_STEPS = [
    {
        "title": "欢迎使用已知行星可视化",
        "body": ("本软件展示太阳系八大行星、冥王星及 76 颗真实系外行星的三维位置与轨道。\n\n"
                 "接下来用 5 步快速了解核心功能（可随时跳过）。"),
        "highlight": None,
    },
    {
        "title": "第 1 步：视角漫游",
        "body": ("• 中键拖拽：旋转视角\n"
                 "• Shift+中键：平移\n"
                 "• 滚轮：缩放（远近自适应）\n"
                 "• 右键：上下文菜单\n\n"
                 "试试旋转视角观察太阳系全貌。"),
        "highlight": "viewport",
    },
    {
        "title": "第 2 步：搜索天体",
        "body": ("顶部搜索栏输入天体名称（中/英文均可），\n"
                 "例如：地球、火星、Kepler-186 f、Proxima\n\n"
                 "左侧天体树也可浏览所有天体，点击即可聚焦。"),
        "highlight": "search",
    },
    {
        "title": "第 3 步：选中行星",
        "body": ("左键点击三维视口中的天体即可选中，\n"
                 "右侧详情面板会显示该天体的完整数据\n"
                 "（轨道根数、物理参数、精度等级等）。\n\n"
                 "缺失数据如实标注'未知'，不伪造。"),
        "highlight": "detail",
    },
    {
        "title": "第 4 步：对比两颗行星",
        "body": ("右键点击天体 → '加入对比'，选两颗后\n"
                 "切换到右侧'对比分析'标签页，\n"
                 "可查看相对运动轨迹、距离/速度曲线、会合周期。\n\n"
                 "支持 4 种参考系切换与 CSV/PNG 导出。"),
        "highlight": "compare",
    },
    {
        "title": "第 5 步：时间控制",
        "body": ("底部时间轴：播放/暂停、倒放、9 档倍速、日期跳转。\n"
                 "倍速从实时×1 到 100年/秒，可快速观察行星运动。\n\n"
                 "空格键 = 播放/暂停，F1 = 帮助。"),
        "highlight": "timeline",
    },
    {
        "title": "准备就绪！",
        "body": ("你已掌握所有核心操作。\n\n"
                 "更多功能：\n"
                 "• 尺寸对比：详情面板 → '尺寸对比'按钮\n"
                 "• 教学场景：菜单 → '教学' → 选择预设场景\n"
                 "• 飞行模式：Shift+~ 进入自由漫游\n"
                 "• F1 随时查看完整快捷键"),
        "highlight": None,
    },
]


class GuideDialog(QDialog):
    """新手引导对话框（步骤卡片式）"""
    guideFinished = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("新手引导")
        self.setModal(True)
        self.resize(440, 320)
        self._step = 0
        self._build_ui()
        self._show_step()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 16)
        layout.setSpacing(12)

        self.lbl_title = QLabel("")
        self.lbl_title.setStyleSheet(
            f"color: {ACCENT}; font-size: 16px; font-weight: bold;")
        layout.addWidget(self.lbl_title)

        self.lbl_body = QLabel("")
        self.lbl_body.setWordWrap(True)
        self.lbl_body.setStyleSheet(f"color: {TEXT_MAIN}; font-size: 13px;")
        self.lbl_body.setMinimumHeight(120)
        layout.addWidget(self.lbl_body, 1)

        # 进度指示
        self.lbl_progress = QLabel("")
        self.lbl_progress.setStyleSheet(f"color: {TEXT_DIM}; font-size: 10px;")
        layout.addWidget(self.lbl_progress)

        # 按钮行
        btn_row = QHBoxLayout()
        self.chk_skip = QCheckBox("不再显示")
        self.chk_skip.setStyleSheet(f"color: {TEXT_DIM};")
        btn_row.addWidget(self.chk_skip)

        btn_row.addStretch()

        self.btn_prev = QPushButton("上一步")
        self.btn_prev.clicked.connect(self._prev)
        btn_row.addWidget(self.btn_prev)

        self.btn_next = QPushButton("下一步")
        self.btn_next.clicked.connect(self._next)
        btn_row.addWidget(self.btn_next)

        self.btn_skip = QPushButton("跳过")
        self.btn_skip.clicked.connect(self._skip)
        btn_row.addWidget(self.btn_skip)

        layout.addLayout(btn_row)

    def _show_step(self):
        step = GUIDE_STEPS[self._step]
        self.lbl_title.setText(step["title"])
        self.lbl_body.setText(step["body"])
        self.lbl_progress.setText(f"步骤 {self._step + 1} / {len(GUIDE_STEPS)}")
        self.btn_prev.setEnabled(self._step > 0)
        self.btn_next.setText("完成" if self._step == len(GUIDE_STEPS) - 1 else "下一步")

    def _prev(self):
        if self._step > 0:
            self._step -= 1
            self._show_step()

    def _next(self):
        if self._step < len(GUIDE_STEPS) - 1:
            self._step += 1
            self._show_step()
        else:
            self._finish()

    def _skip(self):
        self._finish()

    def _finish(self):
        if self.chk_skip.isChecked():
            try:
                with open(GUIDE_FLAG_FILE, "w") as f:
                    json.dump({"completed": True}, f)
            except Exception:
                pass
        self.guideFinished.emit()
        self.accept()


def should_show_guide() -> bool:
    """是否应该显示新手引导（首次启动或未标记完成）"""
    return not os.path.exists(GUIDE_FLAG_FILE)


def mark_guide_completed():
    """标记引导已完成"""
    try:
        with open(GUIDE_FLAG_FILE, "w") as f:
            json.dump({"completed": True}, f)
    except Exception:
        pass