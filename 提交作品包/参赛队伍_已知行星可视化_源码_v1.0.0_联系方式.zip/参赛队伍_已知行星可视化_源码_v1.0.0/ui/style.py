"""
style.py —— Blender 式深色主题（模块 8.1 视觉规范）

配色对标 Blender 深色主题：深灰背景、极简控件、单一克制的高亮色（橙 #e87d0d）。
非纯黑背景、无渐变堆砌、扁平细边框、hover 轻微高亮。
"""

# 颜色常量（供代码引用）
BG_MAIN = "#1d1d1d"        # 主背景（视口同色系）
BG_PANEL = "#333333"       # 面板/侧栏
BG_PANEL_LIGHT = "#3d3d3d" # 更浅层（输入框/hover）
ACCENT = "#e87d0d"         # 强调色（Blender 橙，仅选中/激活态）
ACCENT_BLUE = "#4772b3"    # 备选科技蓝
TEXT_MAIN = "#e5e5e5"      # 主文字
TEXT_DIM = "#a0a0a0"       # 次要文字
BORDER = "#252525"         # 细边框

MAIN_QSS = f"""
QWidget {{
    background-color: {BG_PANEL};
    color: {TEXT_MAIN};
    font-family: "Microsoft YaHei UI", "Segoe UI", sans-serif;
    font-size: 12px;
}}
QMainWindow, QDialog {{
    background-color: {BG_MAIN};
}}
QMenuBar {{
    background-color: {BG_MAIN};
    border-bottom: 1px solid {BORDER};
}}
QMenu {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER};
}}
QMenu::item:selected {{
    background-color: {ACCENT};
    color: #ffffff;
}}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit, QTimeEdit {{
    background-color: {BG_PANEL_LIGHT};
    border: 1px solid {BORDER};
    border-radius: 2px;
    padding: 2px 6px;
    selection-background-color: {ACCENT};
}}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus {{
    border: 1px solid {ACCENT};
}}
QPushButton {{
    background-color: {BG_PANEL_LIGHT};
    border: 1px solid {BORDER};
    border-radius: 2px;
    padding: 3px 10px;
}}
QPushButton:hover {{
    background-color: #4a4a4a;
}}
QPushButton:pressed, QPushButton:checked {{
    background-color: {ACCENT};
    color: #ffffff;
    border: 1px solid {ACCENT};
}}
QTreeWidget, QListWidget, QTableWidget {{
    background-color: {BG_PANEL};
    border: none;
    alternate-background-color: {BG_PANEL_LIGHT};
}}
QTreeWidget::item:selected, QListWidget::item:selected {{
    background-color: {ACCENT};
    color: #ffffff;
}}
QTreeWidget::item:hover, QListWidget::item:hover {{
    background-color: #414141;
}}
QHeaderView::section {{
    background-color: {BG_PANEL_LIGHT};
    border: none;
    padding: 3px;
}}
QSplitter::handle {{
    background-color: {BORDER};
}}
QSplitter::handle:horizontal {{
    width: 6px;
}}
QSplitter::handle:vertical {{
    height: 6px;
}}
QSplitter::handle:hover {{
    background-color: {ACCENT};
}}
QTabBar::tab {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER};
    padding: 4px 12px;
    margin-right: 1px;
}}
QTabBar::tab:selected {{
    background-color: {BG_PANEL_LIGHT};
    border-bottom: 2px solid {ACCENT};
}}
QSlider::groove:horizontal {{
    height: 3px;
    background: {BG_PANEL_LIGHT};
    border-radius: 1px;
}}
QSlider::handle:horizontal {{
    background: {TEXT_DIM};
    width: 10px;
    margin: -4px 0;
    border-radius: 5px;
}}
QSlider::handle:horizontal:hover {{
    background: {ACCENT};
}}
QScrollBar:vertical {{
    background: {BG_MAIN};
    width: 8px;
}}
QScrollBar::handle:vertical {{
    background: {BG_PANEL_LIGHT};
    border-radius: 3px;
    min-height: 20px;
}}
QScrollBar::handle:vertical:hover {{
    background: #4a4a4a;
}}
QScrollBar::add-line, QScrollBar::sub-line {{
    height: 0px;
}}
QLabel#hudLabel {{
    color: {TEXT_DIM};
    font-size: 11px;
}}
QCheckBox::indicator {{
    width: 13px;
    height: 13px;
    border: 1px solid {BORDER};
    background: {BG_PANEL_LIGHT};
}}
QCheckBox::indicator:checked {{
    background: {ACCENT};
}}
QToolTip {{
    background-color: {BG_PANEL_LIGHT};
    color: {TEXT_MAIN};
    border: 1px solid {BORDER};
}}
"""