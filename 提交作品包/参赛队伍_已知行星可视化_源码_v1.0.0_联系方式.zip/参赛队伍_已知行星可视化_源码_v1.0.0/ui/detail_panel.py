"""
detail_panel.py —— 天体详情面板（模块 H）

显示选中天体的完整数据（缺失字段显示"未知"，不伪造）：
    名称/类型/精度等级、轨道根数（a/e/i/Ω/ω/周期）、
    物理参数（半径/质量）、发现信息（年份/方法）、距离、数据来源
并提供：聚焦 / 加入对比 / 尺寸对比（模块 M）入口
"""
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QGridLayout,
                             QLabel, QPushButton, QFrame, QScrollArea)
from data.loader import BODY_TYPE_LABELS
from core.constants import (GRADE_DESCRIPTION, format_distance, AU_KM,
                            R_EARTH_KM, M_EARTH_KG)
from ui.style import TEXT_MAIN, TEXT_DIM, ACCENT

M_SUN_PER_EARTH = 332946.0


def _fmt(v, fmt="{:.6g}", suffix=""):
    if v is None:
        return "未知"
    try:
        return fmt.format(v) + suffix
    except (TypeError, ValueError):
        return "未知"


class DetailPanel(QWidget):
    """天体详情面板"""

    def __init__(self, viewport=None, compare_panel=None, parent=None):
        super().__init__(parent)
        self.viewport = viewport
        self.compare_panel = compare_panel
        self.exo_obs_panel = None      # 由主窗口注入（观测特征面板）
        self.sky_panel = None          # 由主窗口注入（地面视角面板）
        self.surface_panel = None      # 由主窗口注入（地表视角面板）
        self.right_tabs = None         # 由主窗口注入（右侧标签容器）
        self._body = None
        self.setMinimumWidth(280)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)

        self.lbl_title = QLabel("未选中天体")
        self.lbl_title.setStyleSheet(f"color: {TEXT_MAIN}; font-size: 15px; font-weight: bold;")
        layout.addWidget(self.lbl_title)

        self.lbl_grade = QLabel("")
        self.lbl_grade.setWordWrap(True)
        self.lbl_grade.setStyleSheet(f"color: {TEXT_DIM}; font-size: 11px;")
        layout.addWidget(self.lbl_grade)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("color: #252525;")
        layout.addWidget(line)

        self.grid = QGridLayout()
        self.grid.setVerticalSpacing(3)
        layout.addLayout(self.grid)
        layout.addStretch()

        btns = QGridLayout()
        btns.setHorizontalSpacing(6)
        btns.setVerticalSpacing(4)
        self.btn_focus = QPushButton("聚焦")
        self.btn_focus.clicked.connect(self._focus)
        self.btn_compare = QPushButton("加入对比")
        self.btn_compare.clicked.connect(self._compare)
        self.btn_exo = QPushButton("观测特征")
        self.btn_exo.setToolTip(
            "打开「观测特征」标签页：凌星光变曲线 / 视向速度曲线 / 宜居带\n"
            "（太阳系天体仅有宜居带与光通量）")
        self.btn_exo.clicked.connect(self._show_exo_obs)
        self.btn_sky = QPushButton("地面视角")
        self.btn_sky.setToolTip(
            "打开「地面视角」标签页：站在选定地点抬头看天的星空图\n"
            "（行星/太阳/亮星的地平坐标 + 当日日轨线与升落时刻）\n"
            "当前选中天体若在地平线上方会高亮标注")
        self.btn_sky.clicked.connect(self._show_sky)
        self.btn_surface = QPushButton("地表视角")
        self.btn_surface.setToolTip(
            "打开「地表视角」标签页：站到该行星/卫星表面，第一人称环视天空\n"
            "（天空底色随太阳高度变化，亮星为柔和光晕，地平线为静态地形剪影）\n"
            "仅对具备自转轴数据的天体可用")
        self.btn_surface.clicked.connect(self._show_surface)
        self.btn_size = QPushButton("尺寸对比")
        self.btn_size.clicked.connect(self._size_compare)
        btns.addWidget(self.btn_focus, 0, 0)
        btns.addWidget(self.btn_compare, 0, 1)
        btns.addWidget(self.btn_exo, 1, 0)
        btns.addWidget(self.btn_sky, 1, 1)
        btns.addWidget(self.btn_surface, 2, 0)
        btns.addWidget(self.btn_size, 2, 1)
        layout.addLayout(btns)

    # ---------- 显示 ----------
    def show_body(self, body):
        """显示天体详情（缺失显示'未知'）"""
        self._body = body
        self.lbl_title.setText(body.name)
        self.lbl_grade.setText(
            f"类型: {BODY_TYPE_LABELS.get(body.body_type, body.body_type)}   "
            f"精度等级: {body.grade}\n{GRADE_DESCRIPTION.get(body.grade, '')}")
        self._clear_grid()
        rows = []
        rows.append(("英文名", body.en_name or "—"))
        rows.append(("宿主恒星", body.host or ("—" if body.body_type == "star" else "未知")))
        if body.parent_name:
            rows.append(("母行星", body.parent_name))
            plane_txt = "黄道面" if body.plane == "ecliptic" else "母行星赤道面（近似）"
            if body.retro:
                plane_txt += "，逆行轨道"
            rows.append(("卫星轨道面", plane_txt))
        # 轨道根数
        rows.append(("轨道半长轴 a", _fmt(body.a_au, "{:.6g}", " AU")))
        rows.append(("偏心率 e", _fmt(body.e)))
        rows.append(("轨道倾角 i", _fmt(body.incl_deg, "{:.4g}", "°")))
        rows.append(("公转周期", self._period_text(body)))
        # 自转（恒星日）与转轴倾角
        if body.rot_period_days is not None:
            rows.append(("自转周期（恒星日）", self._rot_text(body)))
            rows.append(("自转方向", body.rotation_direction or "未知"))
        if body.axial_tilt_deg is not None:
            rows.append(("转轴倾角", _fmt(body.axial_tilt_deg, "{:.2f}",
                                      "°（自转轴与轨道面法线夹角）")))
        if body.body_type in ("planet_solar", "dwarf"):
            from core.kepler import position_at_time
            el = body.elements
            rows.append(("升交点经度 Ω", _fmt(el.Omega, "{:.4g}", "°")))
            omega = el.varpi - el.Omega
            rows.append(("近心点幅角 ω", _fmt(omega, "{:.4g}", "°")))
            rows.append(("近日点经度 ϖ", _fmt(el.varpi, "{:.4g}", "°")))
        # 物理
        rows.append(("半径", _fmt(body.radius_km, "{:,.1f}", " km")))
        if body.radius_km:
            rows.append(("半径（地球=1）", _fmt(body.radius_km / R_EARTH_KM, "{:.3g}")))
        rows.append(("质量（地球=1）", _fmt(body.mass_earth)))
        if body.mass_earth:
            rows.append(("质量（木星=1）", _fmt(body.mass_earth / 317.8, "{:.4g}")))
        # 发现信息
        rows.append(("发现年份", _fmt(body.disc_year, "{:.0f}")))
        rows.append(("发现方法", body.method or "未知"))
        rows.append(("距地球距离", self._dist_text(body)))
        rows.append(("数据来源", body.data_source or "未知"))
        if body.assumed_phase:
            rows.append(("轨道相位", "假设值（M(J2000)=0，可复现；瞬时位置无预测意义）"))
        # 坐标（系外行星/恒星）
        if body.ra_deg is not None:
            rows.append(("宿主星 RA/Dec", f"{body.ra_deg:.3f}°, {body.dec_deg:.3f}°"))
        self._render_rows(rows)

    # ---------- 恒星系概览（点击左侧恒星系节点） ----------
    def show_system(self, group):
        """显示恒星系概览：宿主恒星参数 + 成员行星清单（不伪造缺失值）"""
        self._body = None
        self.lbl_title.setText("太阳系" if group.is_solar else f"{group.host} 系")
        self.lbl_grade.setText(
            f"恒星系（系群）   成员行星 {group.n_planets} 颗"
            + (f"   天然卫星 {len(group.moons)} 颗" if group.moons else ""))
        self._clear_grid()
        rows = [("宿主恒星", "太阳" if group.is_solar else group.host)]
        rows.append(("恒星光度型", group.spec or "未知"))
        rows.append(("有效温度", _fmt(group.host_teff, "{:.0f}", " K")))
        rows.append(("恒星质量", _fmt(group.host_mass_solar, "{:.3g}", " M☉")))
        rows.append(("恒星半径", _fmt(group.host_radius_solar, "{:.3g}", " R☉")))
        if group.dist_pc:
            rows.append(("距地球距离",
                         f"{group.dist_pc:.4g} pc ≈ {group.dist_pc / 0.3066:.4g} 光年"))
        else:
            rows.append(("距地球距离", "—（太阳系：本星系）" if group.is_solar else "未知"))
        rows.append(("系统恒星数", _fmt(group.star_count, "{:.0f}")))
        if group.planet_count is not None and group.planet_count != group.n_planets:
            rows.append(("官方已确认行星数", _fmt(group.planet_count, "{:.0f}")))
        rows.append(("成员行星", "、".join(b.name for b in group.planets) or "未知"))
        if group.moons:
            rows.append(("天然卫星", "、".join(m.name for m in group.moons)))
        rows.append(("数据来源", "NASA Exoplanet Archive（宿主恒星参数）"
                     if not group.is_solar else "JPL 近似轨道根数 + IAU 物理参数"))
        self._render_rows(rows)

    # ---------- 内部渲染 ----------
    def _clear_grid(self):
        while self.grid.count():
            item = self.grid.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()

    def _render_rows(self, rows):
        for i, (k, v) in enumerate(rows):
            kl = QLabel(k)
            kl.setStyleSheet(f"color: {TEXT_DIM};")
            vl = QLabel(str(v))
            vl.setTextInteractionFlags(Qt.TextSelectableByMouse)
            vl.setStyleSheet(f"color: {TEXT_MAIN};")
            vl.setWordWrap(True)
            self.grid.addWidget(kl, i, 0, Qt.AlignTop)
            self.grid.addWidget(vl, i, 1, Qt.AlignTop)
        self.grid.setColumnStretch(1, 1)

    def _period_text(self, body):
        p = body.period
        if not p:
            return "未知"
        if p < 400:
            return f"{p:.2f} 天"
        return f"{p:.2f} 天（{p / 365.25:.2f} 年）"

    def _rot_text(self, body):
        """自转周期文本：短周期补小时，逆行加标注"""
        p = body.rot_period_days
        if p is None:
            return "未知"
        ap = abs(p)
        txt = f"{ap:.4f} 天" if ap >= 2.0 else f"{ap:.6f} 天（{ap * 24.0:.4f} 小时）"
        if p < 0:
            txt += "，逆行"
        return txt

    def _dist_text(self, body):
        if body.dist_pc is None and body.body_type not in (
                "planet_solar", "dwarf", "moon", "star"):
            return "未知"
        if body.body_type == "star":
            return "—"
        if body.dist_pc is None:
            # 太阳系天体（行星/矮行星/卫星）：当前时刻地心距离（由视口时钟）
            if self.viewport is not None and self.viewport._body_pos is not None:
                try:
                    names = list(map(lambda x: x.name, self.viewport.bodies))
                    i = names.index(body.name)
                    jd = self.viewport.clock.jd
                    earth = next((x for x in self.viewport.bodies if x.name == "地球"), None)
                    if earth:
                        names2 = list(map(lambda x: x.name, self.viewport.bodies))
                        j = names2.index("地球")
                        pe = self.viewport.bodies[j].position_at_jd(jd)
                        pb = body.position_at_jd(jd)
                        d_au = float(((pe - pb) ** 2).sum() ** 0.5)
                        return f"{format_distance(d_au)}（当前地心距离）"
                except Exception:
                    pass
            return "未知"
        ly = body.dist_pc / 0.3066
        return f"{body.dist_pc:.3g} pc ≈ {ly:.3g} 光年"

    # ---------- 动作 ----------
    def _focus(self):
        if self._body and self.viewport:
            self.viewport.focus_body_by_name(self._body.name)

    def _compare(self):
        if self._body and self.compare_panel:
            # 加入对比的第二格（B），A 保持或取当前
            cur_b = self.compare_panel.combo_b.currentText()
            if cur_b == self._body.name and self.compare_panel._body_a != self._body:
                pass
            self.compare_panel.set_pair(
                self.compare_panel._body_a.name if self.compare_panel._body_a and
                self.compare_panel._body_a.name != self._body.name else
                (self.compare_panel.combo_a.currentText()
                 if self.compare_panel.combo_a.currentText() != self._body.name
                 else (self._body.host if self._body.host != "太阳" else "地球")),
                self._body.name)

    def _size_compare(self):
        if not self._body:
            return
        from ui.size_compare import SizeCompareDialog
        dlg = SizeCompareDialog(self._body, self)
        dlg.exec_()

    def _show_exo_obs(self):
        """切换到「观测特征」标签页并载入当前天体"""
        if not self._body or self.exo_obs_panel is None:
            return
        self.exo_obs_panel.set_body(self._body)
        if self.right_tabs is not None:
            self.right_tabs.setCurrentWidget(self.exo_obs_panel)

    def _show_sky(self):
        """切换到「地面视角」标签页（高亮当前选中天体，若有）"""
        if self.sky_panel is None:
            return
        self.sky_panel.refresh()
        if self.right_tabs is not None:
            self.right_tabs.setCurrentWidget(self.sky_panel)

    def _show_surface(self):
        """切换到「地表视角」标签页并站到当前天体表面（不支持则提示）"""
        if self.surface_panel is None:
            return
        ok = True
        if self._body is not None:
            ok = self.surface_panel.set_body(self._body)
        self.surface_panel.refresh()
        if self.right_tabs is not None:
            self.right_tabs.setCurrentWidget(self.surface_panel)
        if not ok and self._body is not None:
            self.lbl_grade.setText(
                self.lbl_grade.text() + "\n（该天体缺少自转轴数据，无法提供地表视角）")