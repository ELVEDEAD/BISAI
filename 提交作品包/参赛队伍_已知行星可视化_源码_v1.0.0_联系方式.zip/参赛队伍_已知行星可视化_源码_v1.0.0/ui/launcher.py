"""
launcher.py —— 启动器（模式选择）窗口

程序入口先弹出本窗口，让用户选择视图模式：
    * 3D 立体视图 → 打开 ui/main_window.py 的三维主窗口
    * 2D 平面视图 → 打开 ui/main_window_2d.py 的二维平面窗口

同一时刻只显示一个主窗口；两个主窗口工具栏的「切换模式」可回到本窗口重新选择。
"""
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel,
                             QPushButton, QFrame)

from ui.style import (BG_MAIN, BG_PANEL, BG_PANEL_LIGHT, ACCENT,
                      ACCENT_BLUE, TEXT_MAIN, TEXT_DIM, BORDER)


class LauncherWindow(QWidget):
    """模式选择窗口：3D 立体视图 / 2D 平面视图"""

    def __init__(self, bodies, stars):
        super().__init__()
        self.bodies = bodies
        self.stars = stars
        self.win3d = None
        self.win2d = None

        self.setWindowTitle("已知行星可视化 —— 选择视图模式")
        self.setMinimumSize(560, 420)
        self.resize(620, 460)
        self.setStyleSheet(self._qss())
        self._build_ui()

    # ---------- 外观 ----------
    def _qss(self):
        return f"""
QWidget#launcherRoot {{ background-color: {BG_MAIN}; }}
QLabel#launcherTitle {{ color: {TEXT_MAIN}; font-size: 22px; font-weight: 600; }}
QLabel#launcherSub   {{ color: {TEXT_DIM}; font-size: 12px; }}
QPushButton#modeCard {{
    background-color: {BG_PANEL};
    border: 1px solid {BORDER};
    border-radius: 6px;
    color: {TEXT_MAIN};
    font-size: 14px;
    text-align: left;
    padding: 16px 20px;
}}
QPushButton#modeCard:hover {{ background-color: {BG_PANEL_LIGHT}; }}
QPushButton#modeCard3d:hover {{ border: 1px solid {ACCENT}; }}
QPushButton#modeCard2d:hover {{ border: 1px solid {ACCENT_BLUE}; }}
QLabel#launcherFoot {{ color: {TEXT_DIM}; font-size: 11px; }}
"""

    def _build_ui(self):
        self.setObjectName("launcherRoot")
        root = QVBoxLayout(self)
        root.setContentsMargins(34, 30, 34, 26)
        root.setSpacing(14)

        title = QLabel("已知行星可视化")
        title.setObjectName("launcherTitle")
        root.addWidget(title)

        sub = QLabel("太阳系 + 系外行星 · 请选择视图模式")
        sub.setObjectName("launcherSub")
        root.addWidget(sub)

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet(f"color: {BORDER};")
        root.addWidget(line)

        root.addSpacing(4)

        row = QHBoxLayout()
        row.setSpacing(14)

        self.btn_3d = QPushButton(
            "3D 立体视图\n\n三维轨道空间 · 可旋转缩放\n实体球 + 程序化表面贴图\n"
            "系外行星与背景亮星")
        self.btn_3d.setObjectName("modeCard3d")
        self.btn_3d.setMinimumHeight(150)
        self.btn_3d.setCursor(Qt.PointingHandCursor)
        self.btn_3d.setToolTip("打开三维立体视图（快捷键 3）")
        self.btn_3d.clicked.connect(lambda: self.show_mode("3d"))
        row.addWidget(self.btn_3d)

        self.btn_2d = QPushButton(
            "2D 平面视图\n\n俯视黄道面的轨道图\n行星轨道椭圆 · 自适应刻度\n"
            "轻量平面 · 便于看轨道关系")
        self.btn_2d.setObjectName("modeCard2d")
        self.btn_2d.setMinimumHeight(150)
        self.btn_2d.setCursor(Qt.PointingHandCursor)
        self.btn_2d.setToolTip("打开二维平面视图（快捷键 2）")
        self.btn_2d.clicked.connect(lambda: self.show_mode("2d"))
        row.addWidget(self.btn_2d)

        root.addLayout(row)
        root.addStretch(1)

        foot = QLabel("两个视图共用同一套数据与分析方法；"
                      "可用主窗口工具栏的「切换模式」随时返回本窗口。")
        foot.setObjectName("launcherFoot")
        foot.setWordWrap(True)
        root.addWidget(foot)

    # ---------- 模式切换 ----------
    def show_mode(self, mode):
        """显示指定模式的主窗口，并隐藏另一个；关闭启动器"""
        try:
            if mode == "3d":
                if self.win3d is None:
                    from ui.main_window import MainWindow
                    self.win3d = MainWindow(self.bodies, self.stars)
                    self.win3d.set_switch_callback(self.reopen)
                if self.win2d is not None:
                    self.win2d.hide()
                self.win3d.show()
                self.win3d.raise_()
                self.win3d.activateWindow()
            elif mode == "2d":
                if self.win2d is None:
                    from ui.main_window_2d import MainWindow2D
                    self.win2d = MainWindow2D(self.bodies, self.stars,
                                              on_switch_mode=self.reopen)
                if self.win3d is not None:
                    self.win3d.hide()
                self.win2d.show()
                self.win2d.raise_()
                self.win2d.activateWindow()
        except Exception:
            # 打包为 --windowed 后 stderr 不可见，异常会被静默吞掉，
            # 表现为「点了没反应」。此处显式弹窗提示，并保留启动器窗口。
            import traceback
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.critical(
                self, "无法打开视图",
                "打开 %s 视图时出错：\n\n%s"
                % (mode.upper(), traceback.format_exc()[-1600:]))
            return
        self.hide()

    def reopen(self):
        """主窗口「切换模式」回调：重新显示启动器"""
        self.show()
        self.raise_()
        self.activateWindow()

    # ---------- 快捷键 ----------
    def keyPressEvent(self, ev):
        if ev.key() == Qt.Key_3:
            self.show_mode("3d")
        elif ev.key() == Qt.Key_2:
            self.show_mode("2d")
        else:
            super().keyPressEvent(ev)